--
-- PostgreSQL database dump
--

\restrict 7RBUyRXz98O6vySvCxqV1Xf5xDP9xHMIQ27H2RPVeBrzl4Dc3rkgc0LWd44X3dR

-- Dumped from database version 14.19 (Ubuntu 14.19-1.pgdg24.04+1)
-- Dumped by pg_dump version 14.19 (Ubuntu 14.19-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ag_catalog; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ag_catalog;


--
-- Name: age; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS age WITH SCHEMA ag_catalog;


--
-- Name: EXTENSION age; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION age IS 'AGE database extension';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: enum_eckwms_instances_tier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_eckwms_instances_tier AS ENUM (
    'free',
    'paid'
);


--
-- Name: find_relevant_solutions(public.vector, character varying, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.find_relevant_solutions(query_embedding public.vector, device_model character varying DEFAULT NULL::character varying, result_limit integer DEFAULT 5) RETURNS TABLE(solution_id integer, solution_title text, solution_text text, success_rate double precision, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        s.id,
        s.solution_title,
        s.solution_text,
        s.success_rate,
        1 - (s.embedding <=> query_embedding) AS similarity
    FROM solutions s
    WHERE
        (device_model IS NULL OR device_model = ANY(s.applicable_models))
    ORDER BY s.embedding <=> query_embedding
    LIMIT result_limit;
END;
$$;


--
-- Name: find_similar_cases(public.vector, double precision, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.find_similar_cases(query_embedding public.vector, similarity_threshold double precision DEFAULT 0.7, result_limit integer DEFAULT 5) RETURNS TABLE(ticket_id integer, ticket_number character varying, problem_description text, solution_applied text, similarity double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        sc.id,
        sc.ticket_number,
        sc.problem_description,
        sc.solution_applied,
        1 - (sc.embedding <=> query_embedding) AS similarity
    FROM support_cases sc
    WHERE sc.resolution_status = 'resolved'
        AND sc.solution_applied IS NOT NULL
        AND 1 - (sc.embedding <=> query_embedding) >= similarity_threshold
    ORDER BY sc.embedding <=> query_embedding
    LIMIT result_limit;
END;
$$;


--
-- Name: get_opal_tracking_summary(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_opal_tracking_summary() RETURNS TABLE(total_orders bigint, with_tracking bigint, in_transit bigint, delivered bigint, pending bigint, tracking_percentage numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(*)::BIGINT AS total_orders,
        COUNT(opal_order_id)::BIGINT AS with_tracking,
        COUNT(*) FILTER (WHERE opal_status ILIKE '%transit%' OR opal_status ILIKE '%unterwegs%')::BIGINT AS in_transit,
        COUNT(*) FILTER (WHERE opal_status ILIKE '%delivered%' OR opal_status ILIKE '%zugestellt%')::BIGINT AS delivered,
        COUNT(*) FILTER (WHERE opal_status ILIKE '%pending%' OR opal_status ILIKE '%offen%')::BIGINT AS pending,
        ROUND(COUNT(opal_order_id) * 100.0 / NULLIF(COUNT(*), 0), 2) AS tracking_percentage
    FROM repair_orders;
END;
$$;


--
-- Name: get_repair_order_from_scan(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_repair_order_from_scan(p_scan_id uuid) RETURNS TABLE(order_id integer, order_number character varying, customer_name text, device_model character varying, repair_status character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT ro.id, ro.order_number, ro.customer_name, ro.device_model, ro.repair_status
    FROM repair_orders ro
    WHERE ro.scan_id = p_scan_id;
END;
$$;


--
-- Name: link_scan_to_repair_order(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.link_scan_to_repair_order(p_scan_id uuid, p_repair_order_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE repair_orders
    SET scan_id = p_scan_id,
        updated_at = NOW()
    WHERE id = p_repair_order_id;
    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION link_scan_to_repair_order(p_scan_id uuid, p_repair_order_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.link_scan_to_repair_order(p_scan_id uuid, p_repair_order_id integer) IS 'Links a scan to a repair order';


--
-- Name: update_scans_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_scans_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW."updatedAt" = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_response_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_response_cache (
    id integer NOT NULL,
    query_embedding public.vector(1536),
    query_text text NOT NULL,
    response_text text NOT NULL,
    context_used jsonb,
    model_version character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    last_used_at timestamp without time zone DEFAULT now(),
    use_count integer DEFAULT 1
);


--
-- Name: ai_response_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_response_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_response_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_response_cache_id_seq OWNED BY public.ai_response_cache.id;


--
-- Name: ai_support_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_support_metrics (
    id integer NOT NULL,
    metric_date date DEFAULT CURRENT_DATE,
    tickets_analyzed integer DEFAULT 0,
    tickets_auto_resolved integer DEFAULT 0,
    avg_response_time_seconds double precision,
    avg_solution_rating double precision,
    total_tokens_used integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: ai_support_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ai_support_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ai_support_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ai_support_metrics_id_seq OWNED BY public.ai_support_metrics.id;


--
-- Name: conversation_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_history (
    id integer NOT NULL,
    ticket_id integer,
    role character varying(20) NOT NULL,
    message text NOT NULL,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_role CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'assistant'::character varying, 'system'::character varying])::text[])))
);


--
-- Name: conversation_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.conversation_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: conversation_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.conversation_history_id_seq OWNED BY public.conversation_history.id;


--
-- Name: device_knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_knowledge (
    id integer NOT NULL,
    device_model character varying(50) NOT NULL,
    common_issue text NOT NULL,
    issue_category character varying(50),
    solution_reference integer,
    warranty_info jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: device_knowledge_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_knowledge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_knowledge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_knowledge_id_seq OWNED BY public.device_knowledge.id;


--
-- Name: eckwms_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eckwms_instances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    server_url character varying(255) NOT NULL,
    api_key character varying(255) NOT NULL,
    tier character varying(50) DEFAULT 'free'::character varying,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT eckwms_instances_tier_check CHECK (((tier)::text = ANY ((ARRAY['free'::character varying, 'paid'::character varying])::text[])))
);


--
-- Name: TABLE eckwms_instances; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.eckwms_instances IS 'eckWMS client instances for multi-tenant support';


--
-- Name: email_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_archive (
    id integer NOT NULL,
    ticket_id integer,
    email_date timestamp without time zone NOT NULL,
    from_address text NOT NULL,
    to_address text,
    subject text,
    body text NOT NULL,
    language character varying(10) DEFAULT 'de'::character varying,
    email_type character varying(20) DEFAULT 'customer'::character varying,
    attachments jsonb,
    created_at timestamp without time zone DEFAULT now(),
    embedding public.vector(1536),
    CONSTRAINT valid_email_type CHECK (((email_type)::text = ANY ((ARRAY['customer'::character varying, 'response'::character varying, 'internal'::character varying])::text[])))
);


--
-- Name: email_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.email_archive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_archive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.email_archive_id_seq OWNED BY public.email_archive.id;


--
-- Name: public_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.public_data (
    id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    data jsonb NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: registered_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registered_devices (
    "deviceId" character varying(255) NOT NULL,
    instance_id uuid,
    is_active boolean DEFAULT true,
    "publicKey" text NOT NULL,
    "deviceName" character varying(255),
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE registered_devices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.registered_devices IS 'Registered mobile devices for eckWMS';


--
-- Name: COLUMN registered_devices."publicKey"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.registered_devices."publicKey" IS 'Base64-encoded Ed25519 public key for device authentication';


--
-- Name: repair_defective_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_defective_parts (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    part_name text NOT NULL,
    part_number character varying(100),
    part_category character varying(100),
    "position" integer,
    quantity integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_defective_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_defective_parts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_defective_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_defective_parts_id_seq OWNED BY public.repair_defective_parts.id;


--
-- Name: repair_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_documents (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    document_type character varying(50) NOT NULL,
    file_name text NOT NULL,
    file_path text NOT NULL,
    file_size integer,
    file_extension character varying(10),
    mime_type character varying(100),
    parsed_content text,
    metadata jsonb,
    content_embedding public.vector(1536),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_documents_id_seq OWNED BY public.repair_documents.id;


--
-- Name: repair_error_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_error_categories (
    id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    category_key character varying(50) NOT NULL,
    description text,
    keywords text[],
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_error_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_error_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_error_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_error_categories_id_seq OWNED BY public.repair_error_categories.id;


--
-- Name: repair_firmware_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_firmware_history (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    kernel_before character varying(50),
    digital_before character varying(50),
    analog_before character varying(50),
    kernel_after character varying(50),
    digital_after character varying(50),
    analog_after character varying(50),
    kernel_changed boolean GENERATED ALWAYS AS (((kernel_before)::text IS DISTINCT FROM (kernel_after)::text)) STORED,
    digital_changed boolean GENERATED ALWAYS AS (((digital_before)::text IS DISTINCT FROM (digital_after)::text)) STORED,
    analog_changed boolean GENERATED ALWAYS AS (((analog_before)::text IS DISTINCT FROM (analog_after)::text)) STORED,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_firmware_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_firmware_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_firmware_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_firmware_history_id_seq OWNED BY public.repair_firmware_history.id;


--
-- Name: repair_laptop_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_laptop_config (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    operating_system character varying(100),
    software_name character varying(100),
    software_version character varying(50),
    interface_type character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_laptop_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_laptop_config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_laptop_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_laptop_config_id_seq OWNED BY public.repair_laptop_config.id;


--
-- Name: repair_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_orders (
    id integer NOT NULL,
    order_number character varying(50) NOT NULL,
    year integer NOT NULL,
    date_of_receipt date,
    ticket_number character varying(50),
    sequence integer,
    customer_name text,
    customer_email text,
    location text,
    device_model character varying(50),
    device_serial character varying(50),
    warranty boolean DEFAULT false,
    self_repair boolean DEFAULT false,
    repair_status character varying(20) DEFAULT 'pending'::character varying,
    error_description text,
    error_category character varying(100),
    troubleshooting text,
    solution_category character varying(100),
    folder_path text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    error_embedding public.vector(1536),
    solution_embedding public.vector(1536),
    excel_data jsonb,
    opal_order_id character varying(100),
    opal_tracking_number character varying(100),
    opal_status character varying(50),
    opal_sender_name text,
    opal_sender_address text,
    opal_recipient_name text,
    opal_recipient_address text,
    opal_shipping_date date,
    opal_delivery_date date,
    opal_delivery_type character varying(100),
    opal_weight numeric(10,2),
    opal_package_count integer,
    opal_notes text,
    opal_last_updated timestamp without time zone,
    opal_raw_data jsonb,
    opal_hwb_number character varying(255),
    opal_ref_number character varying(255),
    opal_actual_delivery_date timestamp without time zone,
    opal_actual_delivery_status character varying(50),
    opal_actual_receiver_name character varying(255),
    cs_de_order_number character varying(50),
    scan_id uuid,
    CONSTRAINT valid_repair_status CHECK (((repair_status)::text = ANY ((ARRAY['temporary'::character varying, 'confirmed'::character varying, 'awaiting_scan'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


--
-- Name: COLUMN repair_orders.opal_actual_delivery_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.repair_orders.opal_actual_delivery_date IS 'Actual delivery date/time when package arrived (parsed from OPAL status)';


--
-- Name: COLUMN repair_orders.opal_actual_delivery_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.repair_orders.opal_actual_delivery_status IS 'Delivery status: OK (delivered), STORNO (cancelled), etc.';


--
-- Name: COLUMN repair_orders.opal_actual_receiver_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.repair_orders.opal_actual_receiver_name IS 'Name of person who physically received the package';


--
-- Name: COLUMN repair_orders.scan_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.repair_orders.scan_id IS 'Link to scan that created or is associated with this repair order';


--
-- Name: repair_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_orders_id_seq OWNED BY public.repair_orders.id;


--
-- Name: repair_package_contents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_package_contents (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    inbody_unit boolean DEFAULT false,
    power_adapter boolean DEFAULT false,
    power_cable boolean DEFAULT false,
    hinge_cover boolean DEFAULT false,
    additional_items jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_package_contents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_package_contents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_package_contents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_package_contents_id_seq OWNED BY public.repair_package_contents.id;


--
-- Name: repair_solution_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_solution_categories (
    id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    category_key character varying(50) NOT NULL,
    description text,
    keywords text[],
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_solution_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_solution_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_solution_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_solution_categories_id_seq OWNED BY public.repair_solution_categories.id;


--
-- Name: repair_support_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_support_links (
    id integer NOT NULL,
    repair_order_id integer NOT NULL,
    support_case_id integer NOT NULL,
    link_type character varying(50) DEFAULT 'related'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: repair_support_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repair_support_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_support_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repair_support_links_id_seq OWNED BY public.repair_support_links.id;


--
-- Name: rma_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rma_requests (
    id uuid NOT NULL,
    "userId" uuid,
    "rmaCode" character varying(255) NOT NULL,
    "orderCode" character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'created'::character varying NOT NULL,
    company character varying(255) NOT NULL,
    person character varying(255),
    street character varying(255) NOT NULL,
    "houseNumber" character varying(255),
    "postalCode" character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "invoiceEmail" character varying(255),
    phone character varying(255),
    "resellerName" character varying(255),
    devices jsonb DEFAULT '[]'::jsonb NOT NULL,
    "orderData" jsonb,
    "receivedAt" timestamp with time zone,
    "processedAt" timestamp with time zone,
    "shippedAt" timestamp with time zone,
    "trackingNumber" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: scans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payload text DEFAULT '{}'::text,
    checksum character varying(255),
    "deviceId" character varying(255),
    instance_id uuid,
    type character varying(255),
    priority integer DEFAULT 0,
    status character varying(255) DEFAULT 'buffered'::character varying,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE scans; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.scans IS 'Unified buffer table for scans from eckwms mobile devices';


--
-- Name: scans_backup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scans_backup (
    id integer,
    payload text,
    checksum character varying(255),
    "deviceId" character varying(255),
    type character varying(255),
    priority integer,
    status character varying(255),
    "createdAt" timestamp with time zone,
    "updatedAt" timestamp with time zone,
    repair_order_id integer
);


--
-- Name: schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_version (
    version integer NOT NULL,
    description text,
    applied_at timestamp without time zone DEFAULT now()
);


--
-- Name: solution_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.solution_feedback (
    id integer NOT NULL,
    ticket_id integer,
    solution_id integer,
    was_helpful boolean,
    feedback_text text,
    rating integer,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT valid_rating CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: solution_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.solution_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: solution_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.solution_feedback_id_seq OWNED BY public.solution_feedback.id;


--
-- Name: solutions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.solutions (
    id integer NOT NULL,
    solution_title text NOT NULL,
    problem_type character varying(100) NOT NULL,
    solution_text text NOT NULL,
    solution_steps jsonb,
    applicable_models text[],
    tags text[],
    success_rate double precision DEFAULT 0.0,
    usage_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    created_by character varying(100),
    embedding public.vector(1536),
    CONSTRAINT valid_success_rate CHECK (((success_rate >= (0.0)::double precision) AND (success_rate <= (1.0)::double precision)))
);


--
-- Name: solutions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.solutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: solutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.solutions_id_seq OWNED BY public.solutions.id;


--
-- Name: support_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_cases (
    id integer NOT NULL,
    ticket_number character varying(20) NOT NULL,
    customer_email text NOT NULL,
    customer_name text,
    device_model character varying(50),
    device_serial character varying(50),
    problem_category character varying(50),
    problem_description text NOT NULL,
    solution_applied text,
    resolution_status character varying(20) DEFAULT 'open'::character varying,
    priority character varying(10) DEFAULT 'normal'::character varying,
    assigned_to character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    resolved_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now(),
    embedding public.vector(1536),
    CONSTRAINT valid_priority CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'normal'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT valid_status CHECK (((resolution_status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


--
-- Name: support_cases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.support_cases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: support_cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.support_cases_id_seq OWNED BY public.support_cases.id;


--
-- Name: translation_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.translation_cache (
    key character varying(32) NOT NULL,
    language character varying(5) NOT NULL,
    "originalText" text NOT NULL,
    "translatedText" text NOT NULL,
    context character varying(100),
    "lastUsed" timestamp with time zone,
    "useCount" integer DEFAULT 1,
    "charCount" integer DEFAULT 0,
    "processingTime" double precision,
    source character varying(20) DEFAULT 'openai'::character varying,
    "apiVersion" character varying(30),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: user_auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_auth (
    id uuid NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    "googleId" character varying(255),
    name character varying(255),
    company character varying(255),
    phone character varying(255),
    street character varying(255),
    "houseNumber" character varying(255),
    "postalCode" character varying(255),
    city character varying(255),
    country character varying(255),
    "lastLogin" timestamp with time zone,
    role character varying(255) DEFAULT 'user'::character varying,
    "userType" character varying(255) DEFAULT 'individual'::character varying,
    "rmaReference" character varying(255),
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: v_common_errors; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_common_errors AS
 SELECT repair_orders.error_description,
    repair_orders.error_category,
    count(*) AS occurrence_count,
    round((((count(*))::numeric * 100.0) / (( SELECT count(*) AS count
           FROM public.repair_orders repair_orders_1
          WHERE (repair_orders_1.error_description IS NOT NULL)))::numeric), 2) AS percentage
   FROM public.repair_orders
  WHERE (repair_orders.error_description IS NOT NULL)
  GROUP BY repair_orders.error_description, repair_orders.error_category
  ORDER BY (count(*)) DESC;


--
-- Name: v_common_solutions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_common_solutions AS
 SELECT repair_orders.troubleshooting,
    repair_orders.solution_category,
    count(*) AS usage_count,
    round((((count(*))::numeric * 100.0) / (( SELECT count(*) AS count
           FROM public.repair_orders repair_orders_1
          WHERE (repair_orders_1.troubleshooting IS NOT NULL)))::numeric), 2) AS percentage,
    round((avg(
        CASE
            WHEN repair_orders.warranty THEN 1
            ELSE 0
        END) * (100)::numeric), 2) AS warranty_percentage
   FROM public.repair_orders
  WHERE (repair_orders.troubleshooting IS NOT NULL)
  GROUP BY repair_orders.troubleshooting, repair_orders.solution_category
  ORDER BY (count(*)) DESC;


--
-- Name: v_defective_parts_statistics; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_defective_parts_statistics AS
 SELECT rdp.part_name,
    rdp.part_category,
    count(*) AS replacement_count,
    count(DISTINCT rdp.repair_order_id) AS affected_repairs,
    json_agg(DISTINCT ro.device_model) AS affected_models,
    round((avg(
        CASE
            WHEN ro.warranty THEN 1
            ELSE 0
        END) * (100)::numeric), 2) AS warranty_rate
   FROM (public.repair_defective_parts rdp
     JOIN public.repair_orders ro ON ((ro.id = rdp.repair_order_id)))
  GROUP BY rdp.part_name, rdp.part_category
  ORDER BY (count(*)) DESC;


--
-- Name: v_device_repair_history; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_device_repair_history AS
SELECT
    NULL::character varying(50) AS device_serial,
    NULL::character varying(50) AS device_model,
    NULL::character varying(50) AS order_number,
    NULL::date AS date_of_receipt,
    NULL::text AS error_description,
    NULL::text AS troubleshooting,
    NULL::boolean AS warranty,
    NULL::json AS defective_parts,
    NULL::timestamp without time zone AS created_at;


--
-- Name: v_firmware_changes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_firmware_changes AS
 SELECT rfh.kernel_before,
    rfh.kernel_after,
    rfh.digital_before,
    rfh.digital_after,
    rfh.analog_before,
    rfh.analog_after,
    count(*) AS change_count,
    json_agg(ro.order_number) AS order_numbers
   FROM (public.repair_firmware_history rfh
     JOIN public.repair_orders ro ON ((ro.id = rfh.repair_order_id)))
  WHERE (rfh.kernel_changed OR rfh.digital_changed OR rfh.analog_changed)
  GROUP BY rfh.kernel_before, rfh.kernel_after, rfh.digital_before, rfh.digital_after, rfh.analog_before, rfh.analog_after
  ORDER BY (count(*)) DESC;


--
-- Name: v_open_tickets; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_open_tickets AS
SELECT
    NULL::integer AS id,
    NULL::character varying(20) AS ticket_number,
    NULL::text AS customer_email,
    NULL::character varying(50) AS device_model,
    NULL::character varying(50) AS device_serial,
    NULL::text AS problem_description,
    NULL::character varying(10) AS priority,
    NULL::timestamp without time zone AS created_at,
    NULL::bigint AS message_count;


--
-- Name: v_repair_orders_with_opal; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_repair_orders_with_opal AS
 SELECT ro.id,
    ro.order_number,
    ro.date_of_receipt,
    ro.customer_name,
    ro.device_model,
    ro.device_serial,
    ro.repair_status,
    ro.opal_order_id,
    ro.opal_tracking_number,
    ro.opal_status,
    ro.opal_shipping_date,
    ro.opal_delivery_date,
    ro.opal_sender_name,
    ro.opal_recipient_name,
    ro.opal_delivery_type,
    ro.opal_last_updated,
        CASE
            WHEN (ro.opal_order_id IS NOT NULL) THEN true
            ELSE false
        END AS has_opal_data
   FROM public.repair_orders ro
  ORDER BY ro.opal_last_updated DESC NULLS LAST, ro.created_at DESC;


--
-- Name: v_scans_with_repairs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_scans_with_repairs AS
 SELECT s.id AS scan_id,
    s."deviceId",
    s.payload,
    s.type,
    s.status AS scan_status,
    s."createdAt" AS scan_created_at,
    ro.id AS repair_order_id,
    ro.order_number,
    ro.customer_name,
    ro.device_model,
    ro.device_serial,
    ro.repair_status,
    ro.error_description,
    ei.name AS instance_name
   FROM ((public.scans s
     LEFT JOIN public.repair_orders ro ON ((ro.scan_id = s.id)))
     LEFT JOIN public.eckwms_instances ei ON ((ei.id = s.instance_id)))
  ORDER BY s."createdAt" DESC;


--
-- Name: v_solution_effectiveness; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_solution_effectiveness AS
SELECT
    NULL::integer AS solution_id,
    NULL::text AS solution_title,
    NULL::character varying(100) AS problem_type,
    NULL::integer AS usage_count,
    NULL::double precision AS success_rate,
    NULL::bigint AS feedback_count,
    NULL::numeric(3,2) AS avg_rating,
    NULL::double precision AS helpful_ratio;


--
-- Name: ai_response_cache id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_response_cache ALTER COLUMN id SET DEFAULT nextval('public.ai_response_cache_id_seq'::regclass);


--
-- Name: ai_support_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_support_metrics ALTER COLUMN id SET DEFAULT nextval('public.ai_support_metrics_id_seq'::regclass);


--
-- Name: conversation_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_history ALTER COLUMN id SET DEFAULT nextval('public.conversation_history_id_seq'::regclass);


--
-- Name: device_knowledge id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_knowledge ALTER COLUMN id SET DEFAULT nextval('public.device_knowledge_id_seq'::regclass);


--
-- Name: email_archive id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_archive ALTER COLUMN id SET DEFAULT nextval('public.email_archive_id_seq'::regclass);


--
-- Name: repair_defective_parts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_defective_parts ALTER COLUMN id SET DEFAULT nextval('public.repair_defective_parts_id_seq'::regclass);


--
-- Name: repair_documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_documents ALTER COLUMN id SET DEFAULT nextval('public.repair_documents_id_seq'::regclass);


--
-- Name: repair_error_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_error_categories ALTER COLUMN id SET DEFAULT nextval('public.repair_error_categories_id_seq'::regclass);


--
-- Name: repair_firmware_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_firmware_history ALTER COLUMN id SET DEFAULT nextval('public.repair_firmware_history_id_seq'::regclass);


--
-- Name: repair_laptop_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_laptop_config ALTER COLUMN id SET DEFAULT nextval('public.repair_laptop_config_id_seq'::regclass);


--
-- Name: repair_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_orders ALTER COLUMN id SET DEFAULT nextval('public.repair_orders_id_seq'::regclass);


--
-- Name: repair_package_contents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_package_contents ALTER COLUMN id SET DEFAULT nextval('public.repair_package_contents_id_seq'::regclass);


--
-- Name: repair_solution_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_solution_categories ALTER COLUMN id SET DEFAULT nextval('public.repair_solution_categories_id_seq'::regclass);


--
-- Name: repair_support_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_support_links ALTER COLUMN id SET DEFAULT nextval('public.repair_support_links_id_seq'::regclass);


--
-- Name: solution_feedback id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solution_feedback ALTER COLUMN id SET DEFAULT nextval('public.solution_feedback_id_seq'::regclass);


--
-- Name: solutions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solutions ALTER COLUMN id SET DEFAULT nextval('public.solutions_id_seq'::regclass);


--
-- Name: support_cases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_cases ALTER COLUMN id SET DEFAULT nextval('public.support_cases_id_seq'::regclass);


--
-- Data for Name: ag_graph; Type: TABLE DATA; Schema: ag_catalog; Owner: -
--

COPY ag_catalog.ag_graph (graphid, name, namespace) FROM stdin;
17992	support_graph	support_graph
\.


--
-- Data for Name: ag_label; Type: TABLE DATA; Schema: ag_catalog; Owner: -
--

COPY ag_catalog.ag_label (name, graph, id, kind, relation, seq_name) FROM stdin;
_ag_label_vertex	17992	1	v	support_graph._ag_label_vertex	_ag_label_vertex_id_seq
_ag_label_edge	17992	2	e	support_graph._ag_label_edge	_ag_label_edge_id_seq
\.


--
-- Data for Name: ai_response_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_response_cache (id, query_embedding, query_text, response_text, context_used, model_version, created_at, last_used_at, use_count) FROM stdin;
\.


--
-- Data for Name: ai_support_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_support_metrics (id, metric_date, tickets_analyzed, tickets_auto_resolved, avg_response_time_seconds, avg_solution_rating, total_tokens_used, created_at) FROM stdin;
\.


--
-- Data for Name: conversation_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_history (id, ticket_id, role, message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: device_knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_knowledge (id, device_model, common_issue, issue_category, solution_reference, warranty_info, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: eckwms_instances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eckwms_instances (id, name, server_url, api_key, tier, "createdAt", "updatedAt") FROM stdin;
00000000-0000-0000-0000-000000000001	InBody Service Center	http://192.168.11.119:3000	inbody_internal_key_a2c93a4e523a35e4954cc27752dbe253	paid	2025-11-10 15:09:19.713104+01	2025-11-10 15:09:19.713104+01
\.


--
-- Data for Name: email_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_archive (id, ticket_id, email_date, from_address, to_address, subject, body, language, email_type, attachments, created_at, embedding) FROM stdin;
\.


--
-- Data for Name: public_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.public_data (id, type, data, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: registered_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registered_devices ("deviceId", instance_id, is_active, "publicKey", "deviceName", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: repair_defective_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_defective_parts (id, repair_order_id, part_name, part_number, part_category, "position", quantity, created_at) FROM stdin;
\.


--
-- Data for Name: repair_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_documents (id, repair_order_id, document_type, file_name, file_path, file_size, file_extension, mime_type, parsed_content, metadata, content_embedding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: repair_error_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_error_categories (id, category_name, category_key, description, keywords, created_at) FROM stdin;
1	Calibration Issues	calibration	Kalibrierungsprobleme	{calibration,kalibrierung,kalibration}	2025-10-24 16:27:55.928901
2	Boot Failures	boot_failure	Gerät startet nicht	{"doesn't boot","startet nicht",boot,power}	2025-10-24 16:27:55.928901
3	Measurement Errors	measurement_error	Messfehler	{measurement,stops,messung,error}	2025-10-24 16:27:55.928901
4	Display Issues	display_issue	Display-Probleme	{display,screen,anzeige,bildschirm}	2025-10-24 16:27:55.928901
5	Hardware Failure	hardware_failure	Hardware-Defekt	{board,component,hardware,defect}	2025-10-24 16:27:55.928901
6	Software Issues	software_issue	Software-Probleme	{software,firmware,program,update}	2025-10-24 16:27:55.928901
7	Noise Interference	noise_interference	Störungen	{noise,interference,störung,rauschen}	2025-10-24 16:27:55.928901
8	Connection Problems	connection_problem	Verbindungsprobleme	{connection,cable,usb,verbindung}	2025-10-24 16:27:55.928901
\.


--
-- Data for Name: repair_firmware_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_firmware_history (id, repair_order_id, kernel_before, digital_before, analog_before, kernel_after, digital_after, analog_after, created_at) FROM stdin;
\.


--
-- Data for Name: repair_laptop_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_laptop_config (id, repair_order_id, operating_system, software_name, software_version, interface_type, notes, created_at) FROM stdin;
\.


--
-- Data for Name: repair_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_orders (id, order_number, year, date_of_receipt, ticket_number, sequence, customer_name, customer_email, location, device_model, device_serial, warranty, self_repair, repair_status, error_description, error_category, troubleshooting, solution_category, folder_path, created_at, updated_at, completed_at, error_embedding, solution_embedding, excel_data, opal_order_id, opal_tracking_number, opal_status, opal_sender_name, opal_sender_address, opal_recipient_name, opal_recipient_address, opal_shipping_date, opal_delivery_date, opal_delivery_type, opal_weight, opal_package_count, opal_notes, opal_last_updated, opal_raw_data, opal_hwb_number, opal_ref_number, opal_actual_delivery_date, opal_actual_delivery_status, opal_actual_receiver_name, cs_de_order_number, scan_id) FROM stdin;
144	OCU-998-508183	2025	2025-11-04	\N	0	Im Family Gym	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:41.999094	2025-10-31 12:46:41.999094	\N	\N	\N	\N	15686516	OCU-998-508183	OK	Im Family Gym	Bahnhostrasse 12-14, DE-06917 Jessen	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-03	2025-11-04	Overnight	43.50	1	\N	2025-11-07 18:00:10.622076	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940451923", "refNumber": "", "internalId": "15686516", "pickupCity": "DE-06917 Jessen", "pickupDate": "03.11.25", "pickupName": "Im Family Gym", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "04.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Bahnhostrasse 12-14", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508183", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "04.11.25 09:03", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940451923", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Im Family Gym", "opalOrderId": "15686516", "deliveryDate": "2025-11-04", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-03", "recipientName": "InBody Deutschland", "senderAddress": "Bahnhostrasse 12-14, DE-06917 Jessen", "trackingNumber": "OCU-998-508183", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-11-04 09:03:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940451923		\N	\N	\N	\N	\N
157	OCU-998-508092	2025	2025-10-30	\N	0	Kona Trade GmbH	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 17:35:21.664925	2025-10-31 17:35:21.664925	\N	\N	\N	\N	15677271	OCU-998-508092	OK	Kona Trade GmbH	Elfser Weg 14, DE-59494 Soest	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-29	2025-10-30	Overnight	43.50	1	\N	2025-11-07 18:00:10.65926	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940448216", "refNumber": "", "internalId": "15677271", "pickupCity": "DE-59494 Soest", "pickupDate": "29.10.25", "pickupName": "Kona Trade GmbH", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "30.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Elfser Weg 14", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508092", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "30.10.25 10:15", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940448216", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Kona Trade GmbH", "opalOrderId": "15677271", "deliveryDate": "2025-10-30", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-29", "recipientName": "InBody Deutschland", "senderAddress": "Elfser Weg 14, DE-59494 Soest", "trackingNumber": "OCU-998-508092", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-30 10:15:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940448216		2025-10-30 00:00:00	OK	DIMI	\N	\N
163	OCU-998-508391	2025	2025-11-06	\N	0	Rasenballsportverein Leipzig GmbH	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-11-06 18:00:26.081999	2025-11-06 18:00:26.081999	\N	\N	\N	\N	15703842	OCU-998-508391	OK	Rasenballsportverein Leipzig GmbH	Cottaweg 7, DE-04177 Leipzig	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-05	2025-11-06	Overnight	43.50	1	\N	2025-11-07 18:00:10.602837	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940455966", "refNumber": "", "internalId": "15703842", "pickupCity": "DE-04177 Leipzig", "pickupDate": "05.11.25", "pickupName": "Rasenballsportverein Leipzig GmbH", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "06.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Cottaweg 7", "pickupTimeTo": "11:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508391", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "06.11.25 10:39", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940455966", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Rasenballsportverein Leipzig GmbH", "opalOrderId": "15703842", "deliveryDate": "2025-11-06", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-05", "recipientName": "InBody Deutschland", "senderAddress": "Cottaweg 7, DE-04177 Leipzig", "trackingNumber": "OCU-998-508391", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-11-06 10:39:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940455966		2025-11-06 00:00:00	OK	DIMI	\N	\N
164	OCU-998-508584	2025	2025-11-11	\N	0	Gesundheitszentrum Pulsnitz GmbH	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-11-07 10:00:23.596489	2025-11-07 10:00:23.596489	\N	\N	\N	\N	15722265	OCU-998-508584	\N	Gesundheitszentrum Pulsnitz GmbH	Bischofswerdaer Str. 38, DE-01896 Pulsnitz	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-10	2025-11-11	Overnight	29.50	1	\N	2025-11-07 18:00:10.547101	{"notes": null, "status": null, "weight": 29.5, "rawData": {"hwbNumber": "041940459772", "refNumber": "", "internalId": "15722265", "pickupCity": "DE-01896 Pulsnitz", "pickupDate": "10.11.25", "pickupName": "Gesundheitszentrum Pulsnitz GmbH", "packageInfo": "1 Pks. 29,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "11.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Bischofswerdaer Str. 38", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508584", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "", "actualDeliveryStatus": "", "actualDeliveryReceiver": ""}, "hwbNumber": "041940459772", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Gesundheitszentrum Pulsnitz GmbH", "opalOrderId": "15722265", "deliveryDate": "2025-11-11", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-10", "recipientName": "InBody Deutschland", "senderAddress": "Bischofswerdaer Str. 38, DE-01896 Pulsnitz", "trackingNumber": "OCU-998-508584", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": null, "actualReceiverName": null, "actualDeliveryStatus": null}	041940459772		\N	\N	\N	\N	\N
162	OCU-998-508450	2025	2025-11-07	\N	0	ML-Sportwelt / Fitness Factory e.K	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-11-06 18:00:26.043574	2025-11-06 18:00:26.043574	\N	\N	\N	\N	15711235	OCU-998-508450	OK	ML-Sportwelt / Fitness Factory e.K	Im Stoeckacker 18, DE-79224 Umkirch	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-06	2025-11-07	Overnight	43.50	1	\N	2025-11-07 18:00:10.586692	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940457465", "refNumber": "", "internalId": "15711235", "pickupCity": "DE-79224 Umkirch", "pickupDate": "06.11.25", "pickupName": "ML-Sportwelt / Fitness Factory e.K", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "07.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Im Stoeckacker 18", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "08:00", "trackingNumber": "OCU-998-508450", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "07.11.25 08:56", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "ERTUG"}, "hwbNumber": "041940457465", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "ML-Sportwelt / Fitness Factory e.K", "opalOrderId": "15711235", "deliveryDate": "2025-11-07", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-06", "recipientName": "InBody Deutschland", "senderAddress": "Im Stoeckacker 18, DE-79224 Umkirch", "trackingNumber": "OCU-998-508450", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-11-07 08:56:00", "actualReceiverName": "ERTUG", "actualDeliveryStatus": "OK"}	041940457465		\N	\N	\N	\N	\N
145	OCU-998-508099	2025	2025-10-31	\N	0	PhysioMed Hecker Gesundheitszentrum	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.008079	2025-10-31 12:46:42.008079	\N	\N	\N	\N	15677610	OCU-998-508099	AKTIV	PhysioMed Hecker Gesundheitszentrum	Kurpfalzstraße 51, DE-69168 Wiesloch	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-30	2025-10-31	Overnight	43.50	1	\N	2025-11-07 18:00:10.636172	{"notes": null, "status": "AKTIV", "weight": 43.5, "rawData": {"hwbNumber": "041940449493", "refNumber": "", "internalId": "15677610", "pickupCity": "DE-69168 Wiesloch", "pickupDate": "30.10.25", "pickupName": "PhysioMed Hecker Gesundheitszentrum", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "31.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Kurpfalzstraße 51", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508099", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "30.10.25 10:47", "actualDeliveryStatus": "AKTIV", "actualDeliveryReceiver": "Fehlanfahrt"}, "hwbNumber": "041940449493", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "PhysioMed Hecker Gesundheitszentrum", "opalOrderId": "15677610", "deliveryDate": "2025-10-31", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-30", "recipientName": "InBody Deutschland", "senderAddress": "Kurpfalzstraße 51, DE-69168 Wiesloch", "trackingNumber": "OCU-998-508099", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-30 10:47:00", "actualReceiverName": "Fehlanfahrt", "actualDeliveryStatus": "AKTIV"}	041940449493		\N	\N	\N	\N	\N
153	OCU-998-507755	2025	2025-10-22	\N	0	Rasenballsport Leipzig GmbH	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.090701	2025-10-31 12:46:42.090701	\N	\N	\N	\N	15647418	OCU-998-507755	AKTIV	Rasenballsport Leipzig GmbH	Cottaweg 7, DE-04177 Leipzig	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-22	2025-10-23	Overnight	43.50	1	\N	2025-10-31 17:35:21.705804	{"notes": null, "status": "AKTIV", "weight": 43.5, "rawData": {"hwbNumber": "041940439847", "refNumber": "", "internalId": "15647418", "pickupCity": "DE-04177 Leipzig", "pickupDate": "22.10.25", "pickupName": "Rasenballsport Leipzig GmbH", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "23.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Cottaweg 7", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "16:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-507755", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "22.10.25 11:24", "actualDeliveryStatus": "AKTIV", "actualDeliveryReceiver": "Fehlanfahrt"}, "hwbNumber": "041940439847", "refNumber": "", "scrapedAt": "2025-10-31T16:35:21.566Z", "senderName": "Rasenballsport Leipzig GmbH", "opalOrderId": "15647418", "deliveryDate": "2025-10-23", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-22", "recipientName": "InBody Deutschland", "senderAddress": "Cottaweg 7, DE-04177 Leipzig", "trackingNumber": "OCU-998-507755", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-22 11:24:00", "actualReceiverName": "Fehlanfahrt", "actualDeliveryStatus": "AKTIV"}	041940439847		2025-10-22 00:00:00	AKTIV	Fehlanfahrt	\N	\N
150	OCU-998-507980	2025	2025-10-28	\N	0	LogoFit	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.061158	2025-10-31 12:46:42.061158	\N	\N	\N	\N	15667042	OCU-998-507980	AKTIV	LogoFit	Ringstraße 1, DE-23758 Oldenburg	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-28	2025-10-29	Overnight	43.50	1	\N	2025-11-07 18:00:10.693674	{"notes": null, "status": "AKTIV", "weight": 43.5, "rawData": {"hwbNumber": "041940446465", "refNumber": "", "internalId": "15667042", "pickupCity": "DE-23758 Oldenburg", "pickupDate": "28.10.25", "pickupName": "LogoFit", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "29.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Ringstraße 1", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-507980", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "28.10.25 09:27", "actualDeliveryStatus": "AKTIV", "actualDeliveryReceiver": "nicht abholbereit"}, "hwbNumber": "041940446465", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "LogoFit", "opalOrderId": "15667042", "deliveryDate": "2025-10-29", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-28", "recipientName": "InBody Deutschland", "senderAddress": "Ringstraße 1, DE-23758 Oldenburg", "trackingNumber": "OCU-998-507980", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-28 09:27:00", "actualReceiverName": "nicht abholbereit", "actualDeliveryStatus": "AKTIV"}	041940446465		2025-10-28 00:00:00	AKTIV	nicht abholbereit	\N	\N
158	OCU-998-508084	2025	2025-10-30	\N	1	Universitätsklinikum Erlangen	\N	\N	\N	\N	f	f	confirmed	\N	\N	\N	\N	/mnt/c/Users/Dmytro/Reparaturen/Dokumente/2025/CS-DE-251030-1_Universitätsklinikum Erlangen	2025-10-31 17:35:21.674297	2025-10-31 17:35:51.238886	\N	\N	\N	\N	15676933	OCU-998-508084	OK	Universitätsklinikum Erlangen	Ulmenweg 18, DE-91054 Erlangen	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-29	2025-10-30	Overnight	25.00	1	\N	2025-11-07 18:00:10.681257	{"notes": null, "status": "OK", "weight": 25, "rawData": {"hwbNumber": "041940448091", "refNumber": "", "internalId": "15676933", "pickupCity": "DE-91054 Erlangen", "pickupDate": "29.10.25", "pickupName": "Universitätsklinikum Erlangen", "packageInfo": "1 Pks. 25,00 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "30.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Ulmenweg 18", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508084", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "30.10.25 10:15", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940448091", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Universitätsklinikum Erlangen", "opalOrderId": "15676933", "deliveryDate": "2025-10-30", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-29", "recipientName": "InBody Deutschland", "senderAddress": "Ulmenweg 18, DE-91054 Erlangen", "trackingNumber": "OCU-998-508084", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-30 10:15:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940448091		2025-10-30 00:00:00	OK	DIMI	CS-DE-251030-1	\N
148	OCU-998-508058	2025	2025-10-30	\N	2	Fitbox Berlin Bergmannkiez	\N	\N	\N	\N	f	f	confirmed	\N	\N	\N	\N	/mnt/c/Users/Dmytro/Reparaturen/Dokumente/2025/CS-DE-251030-2_Fitbox Berlin Bergmannkiez	2025-10-31 12:46:42.036867	2025-11-07 12:00:40.119107	\N	\N	\N	\N	15674825	OCU-998-508058	OK	Fitbox Berlin Bergmannkiez	Mehringdamm 57, DE-10961 Berlin	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-29	2025-10-30	Overnight	43.50	1	\N	2025-11-07 18:00:10.68402	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940448069", "refNumber": "", "internalId": "15674825", "pickupCity": "DE-10961 Berlin", "pickupDate": "29.10.25", "pickupName": "Fitbox Berlin Bergmannkiez", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "30.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Mehringdamm 57", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "13:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508058", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "30.10.25 10:15", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940448069", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Fitbox Berlin Bergmannkiez", "opalOrderId": "15674825", "deliveryDate": "2025-10-30", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-29", "recipientName": "InBody Deutschland", "senderAddress": "Mehringdamm 57, DE-10961 Berlin", "trackingNumber": "OCU-998-508058", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-30 10:15:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940448069		2025-10-30 00:00:00	OK	DIMI	CS-DE-251030-2	\N
152	OCU-998-507388	2025	2025-10-24	\N	0	Bayspo-Bayreuther Zentrum für Sportwissenschaft	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.079872	2025-10-31 12:46:42.079872	\N	\N	\N	\N	15614200	OCU-998-507388	OK	Bayspo-Bayreuther Zentrum für Sportwissenschaft	Universitätsstraße 30, DE-95447 Bayreuth	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-23	2025-10-24	Overnight	45.00	1	\N	2025-11-06 18:00:26.258746	{"notes": null, "status": "OK", "weight": 45, "rawData": {"hwbNumber": "041940439851", "refNumber": "", "internalId": "15614200", "pickupCity": "DE-95447 Bayreuth", "pickupDate": "23.10.25", "pickupName": "Bayspo-Bayreuther Zentrum für Sportwissenschaft", "packageInfo": "1 Pks. 45,00 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "24.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Universitätsstraße 30", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "16:00", "pickupTimeFrom": "08:00", "trackingNumber": "OCU-998-507388", "deliveryTimeFrom": "08:00", "actualDeliveryDate": "24.10.25 09:56", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940439851", "refNumber": "", "scrapedAt": "2025-11-06T17:00:25.706Z", "senderName": "Bayspo-Bayreuther Zentrum für Sportwissenschaft", "opalOrderId": "15614200", "deliveryDate": "2025-10-24", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-23", "recipientName": "InBody Deutschland", "senderAddress": "Universitätsstraße 30, DE-95447 Bayreuth", "trackingNumber": "OCU-998-507388", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-24 09:56:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940439851		2025-10-24 00:00:00	OK	DIMI	\N	\N
151	OCU-998-507793	2025	2025-10-23	\N	0	LogoFit	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.071531	2025-10-31 12:46:42.071531	\N	\N	\N	\N	15651192	OCU-998-507793	AKTIV	LogoFit	Ringstraße 1, DE-23758 Oldenburg	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-23	2025-10-24	Overnight	43.50	1	\N	2025-11-07 18:00:10.712307	{"notes": null, "status": "AKTIV", "weight": 43.5, "rawData": {"hwbNumber": "041940441027", "refNumber": "", "internalId": "15651192", "pickupCity": "DE-23758 Oldenburg", "pickupDate": "23.10.25", "pickupName": "LogoFit", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "24.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Ringstraße 1", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "16:00", "pickupTimeFrom": "08:00", "trackingNumber": "OCU-998-507793", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "23.10.25 10:23", "actualDeliveryStatus": "AKTIV", "actualDeliveryReceiver": "Fehlanfahrt"}, "hwbNumber": "041940441027", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "LogoFit", "opalOrderId": "15651192", "deliveryDate": "2025-10-24", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-23", "recipientName": "InBody Deutschland", "senderAddress": "Ringstraße 1, DE-23758 Oldenburg", "trackingNumber": "OCU-998-507793", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-23 10:23:00", "actualReceiverName": "Fehlanfahrt", "actualDeliveryStatus": "AKTIV"}	041940441027		2025-10-23 00:00:00	AKTIV	Fehlanfahrt	\N	\N
161	OCU-998-508541	2025	2025-11-10	\N	0	Traunmed	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-11-06 18:00:25.977209	2025-11-06 18:00:25.977209	\N	\N	\N	\N	15718585	OCU-998-508541	\N	Traunmed	Martin Niemöller Strasse 2, DE-83301 Traunreut	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-07	2025-11-10	Overnight	17.50	1	\N	2025-11-07 18:00:10.559101	{"notes": null, "status": null, "weight": 17.5, "rawData": {"hwbNumber": "041940458715", "refNumber": "", "internalId": "15718585", "pickupCity": "DE-83301 Traunreut", "pickupDate": "07.11.25", "pickupName": "Traunmed", "packageInfo": "1 Pks. 17,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "10.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Martin Niemöller Strasse 2", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "16:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508541", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "", "actualDeliveryStatus": "", "actualDeliveryReceiver": ""}, "hwbNumber": "041940458715", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Traunmed", "opalOrderId": "15718585", "deliveryDate": "2025-11-10", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-07", "recipientName": "InBody Deutschland", "senderAddress": "Martin Niemöller Strasse 2, DE-83301 Traunreut", "trackingNumber": "OCU-998-508541", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": null, "actualReceiverName": null, "actualDeliveryStatus": null}	041940458715		\N	\N	\N	\N	\N
142	OCU-998-508263	2025	2025-11-04	\N	0	Nikola Blajic	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:41.979645	2025-10-31 12:46:41.979645	\N	\N	\N	\N	15691982	OCU-998-508263	OK	Nikola Blajic	Bahnhofstrasse 3, DE-54568 Gerolstein	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-03	2025-11-04	Overnight	43.50	1	\N	2025-11-07 18:00:10.613885	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940451926", "refNumber": "", "internalId": "15691982", "pickupCity": "DE-54568 Gerolstein", "pickupDate": "03.11.25", "pickupName": "Nikola Blajic", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "04.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Bahnhofstrasse 3", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508263", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "04.11.25 09:03", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940451926", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Nikola Blajic", "opalOrderId": "15691982", "deliveryDate": "2025-11-04", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-03", "recipientName": "InBody Deutschland", "senderAddress": "Bahnhofstrasse 3, DE-54568 Gerolstein", "trackingNumber": "OCU-998-508263", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-11-04 09:03:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940451926		\N	\N	\N	\N	\N
159	OCU-998-508052	2025	2025-10-30	\N	0	LogoFit	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 17:35:21.686646	2025-10-31 17:35:21.686646	\N	\N	\N	\N	15674215	OCU-998-508052	OK	LogoFit	Ringstraße 1, DE-23758 Oldenburg	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-29	2025-10-30	Overnight	43.50	1	\N	2025-11-07 18:00:10.686757	{"notes": null, "status": "OK", "weight": 43.5, "rawData": {"hwbNumber": "041940448059", "refNumber": "", "internalId": "15674215", "pickupCity": "DE-23758 Oldenburg", "pickupDate": "29.10.25", "pickupName": "LogoFit", "packageInfo": "1 Pks. 43,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "30.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Ringstraße 1", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508052", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "30.10.25 10:15", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940448059", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "LogoFit", "opalOrderId": "15674215", "deliveryDate": "2025-10-30", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-29", "recipientName": "InBody Deutschland", "senderAddress": "Ringstraße 1, DE-23758 Oldenburg", "trackingNumber": "OCU-998-508052", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-30 10:15:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940448059		2025-10-30 00:00:00	OK	DIMI	\N	\N
154	OCU-998-507552	2025	2025-10-23	\N	0	Clever Fit Kempten	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 12:46:42.099341	2025-10-31 12:46:42.099341	\N	\N	\N	\N	15628356	OCU-998-507552	OK	Clever Fit Kempten	Bahnhofstrasse 1, DE-87435 Kempten	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-22	2025-10-23	Overnight	17.50	1	\N	2025-10-31 17:35:21.709044	{"notes": null, "status": "OK", "weight": 17.5, "rawData": {"hwbNumber": "041940439846", "refNumber": "", "internalId": "15628356", "pickupCity": "DE-87435 Kempten", "pickupDate": "22.10.25", "pickupName": "Clever Fit Kempten", "packageInfo": "1 Pks. 17,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "23.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Bahnhofstrasse 1", "pickupTimeTo": "13:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "16:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-507552", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "23.10.25 09:15", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "HR ARTUG"}, "hwbNumber": "041940439846", "refNumber": "", "scrapedAt": "2025-10-31T16:35:21.566Z", "senderName": "Clever Fit Kempten", "opalOrderId": "15628356", "deliveryDate": "2025-10-23", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-22", "recipientName": "InBody Deutschland", "senderAddress": "Bahnhofstrasse 1, DE-87435 Kempten", "trackingNumber": "OCU-998-507552", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-23 09:15:00", "actualReceiverName": "HR ARTUG", "actualDeliveryStatus": "OK"}	041940439846		2025-10-23 00:00:00	OK	HR ARTUG	\N	\N
143	OCU-998-508261	2025	2025-11-04	\N	1	Health Coach Bardo	\N	\N	\N	\N	f	f	confirmed	\N	\N	\N	\N	/mnt/c/Users/Dmytro/Reparaturen/Dokumente/2025/CS-DE-251104-1_Health Coach Bardo	2025-10-31 12:46:41.990178	2025-11-07 11:26:21.910614	\N	\N	\N	\N	15691950	OCU-998-508261	OK	Health Coach Bardo	Toulouser Allee 7, DE-40211 Düsseldorf	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-11-03	2025-11-04	Overnight	17.50	1	\N	2025-11-07 18:00:10.618037	{"notes": null, "status": "OK", "weight": 17.5, "rawData": {"hwbNumber": "041940451925", "refNumber": "", "internalId": "15691950", "pickupCity": "DE-40211 Düsseldorf", "pickupDate": "03.11.25", "pickupName": "Health Coach Bardo", "packageInfo": "1 Pks. 17,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "04.11.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Toulouser Allee 7", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "09:00", "trackingNumber": "OCU-998-508261", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "04.11.25 09:03", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "DIMI"}, "hwbNumber": "041940451925", "refNumber": "", "scrapedAt": "2025-11-07T17:00:10.448Z", "senderName": "Health Coach Bardo", "opalOrderId": "15691950", "deliveryDate": "2025-11-04", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-11-03", "recipientName": "InBody Deutschland", "senderAddress": "Toulouser Allee 7, DE-40211 Düsseldorf", "trackingNumber": "OCU-998-508261", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-11-04 09:03:00", "actualReceiverName": "DIMI", "actualDeliveryStatus": "OK"}	041940451925		\N	\N	\N	CS-DE-251104-1	\N
160	OCU-998-507712	2025	2025-10-23	\N	0	Fitnessforum	\N	\N	\N	\N	f	f	awaiting_scan	\N	\N	\N	\N		2025-10-31 17:35:21.721367	2025-10-31 17:35:21.721367	\N	\N	\N	\N	15644226	OCU-998-507712	OK	Fitnessforum	Georg-dreke-Ring 60, DE-17291 Prenzlau	InBody Deutschland	Mergenthalerallee 15-21, DE-65760 Eschborn	2025-10-22	2025-10-23	Overnight	29.50	1	\N	2025-10-31 17:35:21.721367	{"notes": null, "status": "OK", "weight": 29.5, "rawData": {"hwbNumber": "041940439841", "refNumber": "", "internalId": "15644226", "pickupCity": "DE-17291 Prenzlau", "pickupDate": "22.10.25", "pickupName": "Fitnessforum", "packageInfo": "1 Pks. 29,50 kg", "productType": "Overnight", "deliveryCity": "DE-65760 Eschborn", "deliveryDate": "23.10.25", "deliveryName": "InBody Deutschland", "pickupStreet": "Georg-dreke-Ring 60", "pickupTimeTo": "12:00", "deliveryStreet": "Mergenthalerallee 15-21", "deliveryTimeTo": "15:00", "pickupTimeFrom": "08:00", "trackingNumber": "OCU-998-507712", "deliveryTimeFrom": "09:00", "actualDeliveryDate": "23.10.25 09:16", "actualDeliveryStatus": "OK", "actualDeliveryReceiver": "HR ARTUG"}, "hwbNumber": "041940439841", "refNumber": "", "scrapedAt": "2025-10-31T16:35:21.566Z", "senderName": "Fitnessforum", "opalOrderId": "15644226", "deliveryDate": "2025-10-23", "deliveryType": "Overnight", "packageCount": 1, "shippingDate": "2025-10-22", "recipientName": "InBody Deutschland", "senderAddress": "Georg-dreke-Ring 60, DE-17291 Prenzlau", "trackingNumber": "OCU-998-507712", "recipientAddress": "Mergenthalerallee 15-21, DE-65760 Eschborn", "actualDeliveryDate": "2025-10-23 09:16:00", "actualReceiverName": "HR ARTUG", "actualDeliveryStatus": "OK"}	041940439841		2025-10-23 00:00:00	OK	HR ARTUG	\N	\N
\.


--
-- Data for Name: repair_package_contents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_package_contents (id, repair_order_id, inbody_unit, power_adapter, power_cable, hinge_cover, additional_items, notes, created_at) FROM stdin;
\.


--
-- Data for Name: repair_solution_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_solution_categories (id, category_name, category_key, description, keywords, created_at) FROM stdin;
1	Calibration	calibration	Kalibrierung durchgeführt	{calibration,kalibrierung,kalibration}	2025-10-24 16:27:55.949763
2	Board Replacement	board_replacement	Platine ersetzt	{"replaced board",board,platine,analog,digital}	2025-10-24 16:27:55.949763
3	Part Replacement	part_replacement	Teil ersetzt	{replaced,ersetzt,arm,foot,electrode}	2025-10-24 16:27:55.949763
4	Firmware Update	firmware_update	Firmware aktualisiert	{firmware,update,flash,software}	2025-10-24 16:27:55.949763
5	Cleaning	cleaning	Reinigung	{cleaning,reinigung,electrode}	2025-10-24 16:27:55.949763
6	Testing Only	testing_only	Nur Test	{test,check,prüfung,"no error"}	2025-10-24 16:27:55.949763
\.


--
-- Data for Name: repair_support_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_support_links (id, repair_order_id, support_case_id, link_type, notes, created_at) FROM stdin;
\.


--
-- Data for Name: rma_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rma_requests (id, "userId", "rmaCode", "orderCode", status, company, person, street, "houseNumber", "postalCode", city, country, email, "invoiceEmail", phone, "resellerName", devices, "orderData", "receivedAt", "processedAt", "shippedAt", "trackingNumber", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scans (id, payload, checksum, "deviceId", instance_id, type, priority, status, "createdAt", "updatedAt") FROM stdin;
bb3d31a8-cbd5-437a-a559-c0f24d78eb2e	image-1762509641300-146283010.webp	ce5884b0	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:00:41.367613+01	2025-11-07 11:00:41.367613+01
ef9caa8e-0b79-4490-b704-daed03c3b9d8	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 11:02:20.614825+01	2025-11-07 11:02:20.614825+01
86420b29-9bae-457b-aa0d-83da709ca04d	TEST-BARCODE-123	\N	test-device	\N	scanner	0	buffered	2025-11-07 11:02:46.576879+01	2025-11-07 11:02:46.576879+01
1b742af9-3923-414c-9ac3-12f6b0060330	DUSFRA6Z04194045192501	cd437510	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 11:17:19.413734+01	2025-11-07 11:17:19.413734+01
d24f21ad-3b9b-45c2-92cb-2003c35bd733	TXLFRA0J04194044806901	bbcd5a18	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 11:40:12.052707+01	2025-11-07 11:40:12.052707+01
052664ab-4762-43e6-b706-86fa8d66dbde	image-1762512043524-500453134.webp	02ca67e2	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:40:43.596815+01	2025-11-07 11:40:43.596815+01
cd22d20d-175b-4a54-afc4-6099d3e1217a	image-1762512110620-857259731.webp	dbf34fd9	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:41:50.710744+01	2025-11-07 11:41:50.710744+01
c422086e-b69d-460e-9128-db60dc37bb42	F91704219	2ed86064	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 11:41:54.434825+01	2025-11-07 11:41:54.434825+01
508c45ef-f514-4f8b-8340-826e35d3aec7	F91704219	340cd5e7	ac8ee24e54707128	\N	CODE_128	0	buffered	2025-11-07 11:42:30.843014+01	2025-11-07 11:42:30.843014+01
8c7dcefa-3912-4ee8-af57-44473c683c2c	F91704219	340cd5e7	ac8ee24e54707128	\N	CODE_128	0	buffered	2025-11-07 11:43:00.994946+01	2025-11-07 11:43:00.994946+01
82193af5-d373-470b-b27f-e27999cd04e7	F91704219	2ed86064	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 11:43:19.897662+01	2025-11-07 11:43:19.897662+01
835a144a-1a7e-4c12-8ca4-26075e920b20	image-1762512301123-527360661.webp	e8d9bc15	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:45:01.207781+01	2025-11-07 11:45:01.207781+01
1d82c8bf-c61d-4566-b600-0e013d08c093	image-1762512357081-39446633.webp	dae21b84	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:45:57.179885+01	2025-11-07 11:45:57.179885+01
7172c2e1-f19d-4f2e-ba2f-48a3c69db359	image-1762512705705-424048410.webp	3138dfae	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:51:45.807393+01	2025-11-07 11:51:45.807393+01
d08d534e-62db-4d68-8dc0-030d03bb5b86	image-1762512733857-80549889.webp	4646ef96	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:52:13.932832+01	2025-11-07 11:52:13.932832+01
8c4868dd-41f7-4288-8328-802a38146ab4	image-1762512742818-291102075.webp	6c99152b	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:52:22.884027+01	2025-11-07 11:52:22.884027+01
e66e8d48-f658-4377-ab68-8bb8c4d28e82	image-1762512762096-221205998.webp	c969a9b9	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:52:42.208474+01	2025-11-07 11:52:42.208474+01
894f9d34-b71b-491a-b89a-c50376bcf77e	image-1762512793795-446607352.webp	fab03682	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:53:13.863625+01	2025-11-07 11:53:13.863625+01
7beb2ee3-0a34-4e1e-a4c3-0980c250307e	image-1762512821206-297654870.webp	659dbe5e	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 11:53:41.305607+01	2025-11-07 11:53:41.305607+01
55020bbf-a3d4-440c-bbe8-4d821265652a	OCU998503628	f0015117	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 11:59:17.087412+01	2025-11-07 11:59:17.087412+01
61852118-a31d-4ea0-b3f0-6f560730e403	image-1762523418976-816141001.webp	a09a506b	ac8ee24e54707128	\N	direct_upload	0	uploaded	2025-11-07 14:50:19.013439+01	2025-11-07 14:50:19.013439+01
dfa0f46c-6f71-4fc6-b16e-6d2ba10fa91d	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 14:56:54.728561+01	2025-11-07 14:56:54.728561+01
e5cae828-027d-4547-8ef5-720ce8dc53a2	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 14:57:10.328741+01	2025-11-07 14:57:10.328741+01
acb618a1-3c1f-4863-b2e7-a388810180a9	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 14:57:15.326677+01	2025-11-07 14:57:15.326677+01
678eb04b-bdc4-414a-89a9-fd655bf15bf0	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 14:57:18.234778+01	2025-11-07 14:57:18.234778+01
a90e13ad-c2b8-423a-9183-6a8f93283b4a	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:03:51.21727+01	2025-11-07 15:03:51.21727+01
d3e1ee0c-9f5d-4e33-ae60-d0367815ef57	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:03:56.133123+01	2025-11-07 15:03:56.133123+01
aec1ee03-376e-409b-9ee9-50c40c596c21	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:06:14.917643+01	2025-11-07 15:06:14.917643+01
204fedcb-c766-4224-9a18-84288aed3720	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:06:17.545064+01	2025-11-07 15:06:17.545064+01
a43b369c-88fd-401f-8aaa-d0a1a448f828	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:10:19.186659+01	2025-11-07 15:10:19.186659+01
d21b17c2-4a40-4701-b180-99382b885446	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:10:29.08171+01	2025-11-07 15:10:29.08171+01
e8159b20-9538-4cc2-a8bc-f2882e0b886e	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:10:32.878652+01	2025-11-07 15:10:32.878652+01
7a89a875-aca5-495d-9634-16c31ce563d6	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:38:09.749643+01	2025-11-07 15:38:09.749643+01
9e204a5b-72cb-473a-9ab3-6771a5b3e11d	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:36.04456+01	2025-11-07 15:40:36.04456+01
88ed4991-4b31-4965-987b-dc545dc295aa	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:38.229639+01	2025-11-07 15:40:38.229639+01
acc5e4d9-87cf-4499-8947-28d88b5b7862	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:41.527212+01	2025-11-07 15:40:41.527212+01
e6e5941b-e1d4-4a24-ab0a-9a2750dff60b	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:44.027334+01	2025-11-07 15:40:44.027334+01
5e08697e-ba70-40cb-bd8f-02b30e542111	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:53.054042+01	2025-11-07 15:40:53.054042+01
14764bc4-5925-43d7-81eb-24c522e79e96	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:40:55.87245+01	2025-11-07 15:40:55.87245+01
2b1301dc-14d3-4452-82fa-a2549e1bf656	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:04.82067+01	2025-11-07 15:41:04.82067+01
a01eeaca-2b3f-4b16-84bb-903c1fc85f03	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:08.452536+01	2025-11-07 15:41:08.452536+01
f6950580-13a8-4aff-bcdb-2a9253c6c168	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:10.830169+01	2025-11-07 15:41:10.830169+01
029f0582-576d-45de-8278-081b27021b51	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:13.492061+01	2025-11-07 15:41:13.492061+01
ed0a3d09-6702-4edf-8fbe-b47b852cae24	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:31.479764+01	2025-11-07 15:41:31.479764+01
24506365-c202-4be2-b407-186889112964	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:34.548163+01	2025-11-07 15:41:34.548163+01
bbdb9398-9735-452b-bf0c-ddf08654c789	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:37.29442+01	2025-11-07 15:41:37.29442+01
3e72faf1-9c09-4498-adb1-323ffe705436	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:41:39.456106+01	2025-11-07 15:41:39.456106+01
c112b71b-6874-4ff1-926a-a0a237a14ff1	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:49:01.168407+01	2025-11-07 15:49:01.168407+01
d94b59da-4210-4027-9a5a-d0290b3a6cac	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:49:07.038561+01	2025-11-07 15:49:07.038561+01
6a59b0b4-d0b8-4197-9946-2c4bf6717708	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:49:09.464173+01	2025-11-07 15:49:09.464173+01
66be0ab5-7f4d-428b-ba5b-f35b65e5eee1	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:49:12.353655+01	2025-11-07 15:49:12.353655+01
9b9772c5-41cb-4638-8447-cd85a3cb974a	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:49:14.516937+01	2025-11-07 15:49:14.516937+01
b2ac8123-85b4-43f9-ba2d-d09f97091d5a	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:56:26.494702+01	2025-11-07 15:56:26.494702+01
d443313d-64d6-45a7-a73c-ca53134075db	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:56:30.046939+01	2025-11-07 15:56:30.046939+01
70823582-f972-4eae-8925-0408b7667e11	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:56:42.666303+01	2025-11-07 15:56:42.666303+01
d2e0a493-5b0d-4f8b-a992-ad0051fedc90	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 15:56:45.254001+01	2025-11-07 15:56:45.254001+01
b350c4cc-3721-42ec-834a-ba48b89fcdd1	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:00:45.090106+01	2025-11-07 16:00:45.090106+01
f004ef42-d8bc-4566-8ee8-fbc139722a38	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:00:47.357332+01	2025-11-07 16:00:47.357332+01
5507df78-fec9-49ca-9ec2-c2f990fc9d49	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:03:56.260457+01	2025-11-07 16:03:56.260457+01
48b93c27-9b82-46ea-89cc-681f4e92164f	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:03:58.446526+01	2025-11-07 16:03:58.446526+01
861910cf-b082-4ba3-bee5-a07ea6d032c6	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:04:59.126668+01	2025-11-07 16:04:59.126668+01
2552a39d-422c-414a-8dda-72abdeb3c503	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:05:01.724621+01	2025-11-07 16:05:01.724621+01
15735842-8584-49f3-b157-d66140080bcc	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:06:40.713842+01	2025-11-07 16:06:40.713842+01
0eafb5ec-bfd2-4c8a-88f8-985f8ea70b3e	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:06:45.596875+01	2025-11-07 16:06:45.596875+01
44fa3799-644e-47f8-8b56-de41aaf50377	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:09:05.672079+01	2025-11-07 16:09:05.672079+01
f80d89b0-b525-4aac-be54-0bbfec3e0ef6	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:09:08.801416+01	2025-11-07 16:09:08.801416+01
e74360fb-c305-4fdf-9b82-0c8e30fe927a	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:09:11.088049+01	2025-11-07 16:09:11.088049+01
5c17c174-9732-4fc4-95db-67ba3a8773d8	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:09:14.408648+01	2025-11-07 16:09:14.408648+01
816d0b35-0fec-458a-875c-7a8f917026f3	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:09:39.036469+01	2025-11-07 16:09:39.036469+01
a766b8d1-a993-44fc-a0b6-5cb6ac5b670d	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:09:44.569505+01	2025-11-07 16:09:44.569505+01
fdb9b8df-d523-49ca-9af8-89aa79988c1a	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:09:49.903477+01	2025-11-07 16:09:49.903477+01
8f04a7ba-6fd0-4544-b4f2-9662d5133acc	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:10:09.622071+01	2025-11-07 16:10:09.622071+01
0cee7805-c9fc-449b-a1f8-3e940e1ee1ba	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F920001Board LNO4 470/270	2359d22c	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:10:52.43172+01	2025-11-07 16:10:52.43172+01
5861111a-35e9-49d4-a79a-d3fcc7c9444c	I8F920001	c28a9973	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:10:56.208909+01	2025-11-07 16:10:56.208909+01
b835d1ca-543f-456c-8663-26e0c38cac24	I8F920001	c28a9973	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:11:11.2192+01	2025-11-07 16:11:11.2192+01
41d26e6c-be42-4a17-8dc5-bceabc33116b	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:27:25.998063+01	2025-11-07 16:27:25.998063+01
4e8118e2-3525-44cc-8b28-eec81e4866cb	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:27:27.659581+01	2025-11-07 16:27:27.659581+01
f8a91d38-5c9c-4428-91aa-ebd07a6c5464	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:27:36.18849+01	2025-11-07 16:27:36.18849+01
55c1886d-38cf-4885-aa2a-e3ab8a33c8f3	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301732P_Display Back EMI 470/270	b4723ba2	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:28:57.568946+01	2025-11-07 16:28:57.568946+01
5025c7ad-4979-49d2-8f99-7bc93ce7a718	I10301732	ff4c67bb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:29:11.006451+01	2025-11-07 16:29:11.006451+01
acc62806-1345-4a16-b3f2-02edc00883a1	I10301732	ff4c67bb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:29:13.715711+01	2025-11-07 16:29:13.715711+01
5ec859ac-803c-4673-8f9f-d146923711fa	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301733P_Display Front New EMI 470/270	128fd0f7	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:29:32.565826+01	2025-11-07 16:29:32.565826+01
183ab6b3-43a6-467a-862d-2d2550bf004e	I10301733	9a2b5cfd	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:29:35.828991+01	2025-11-07 16:29:35.828991+01
9ef2579e-a13b-4b21-8ed5-d62c33c579fa	I10301733	9a2b5cfd	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:29:38.583106+01	2025-11-07 16:29:38.583106+01
517fb121-f0ef-45ab-8308-77175326b3a9	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301653P_Display Front New 470/270	bcc82b18	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:29:49.877229+01	2025-11-07 16:29:49.877229+01
de6ce0ad-182d-440a-9e45-243c768f713c	I10301653	7b3e3dfb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:29:59.355137+01	2025-11-07 16:29:59.355137+01
bf3904de-cea6-4213-87eb-8df04479a85b	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301652P_Bezel New 270	4e31e1a1	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:30:08.207129+01	2025-11-07 16:30:08.207129+01
92db9b75-1d6f-4500-bb54-9d4e059a846a	I10301652	1e5906bd	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:30:10.48294+01	2025-11-07 16:30:10.48294+01
02f271fc-de21-438d-baf9-5d25d2322bc9	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301455P_Shoulder Cap 470/270	109762a6	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:30:20.395204+01	2025-11-07 16:30:20.395204+01
80598b6c-1d21-4ae6-9f26-b09d11d70949	I10301455	d14d69ae	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:30:46.797133+01	2025-11-07 16:30:46.797133+01
a495d1d9-5ae9-492e-86c3-cb7561f42541	I10301455	d14d69ae	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:30:49.240752+01	2025-11-07 16:30:49.240752+01
3ec94b99-bde1-4d49-bfa0-fb417e4f5677	I10301455	d14d69ae	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:30:52.357096+01	2025-11-07 16:30:52.357096+01
680ee654-ac73-4fe9-845f-d99eb627bf74	I10301455	d14d69ae	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:32:41.272221+01	2025-11-07 16:32:41.272221+01
fdccda67-0f9b-4bf8-83d5-1b5be78fc245	I10301455	d14d69ae	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:32:43.64799+01	2025-11-07 16:32:43.64799+01
2afd2b8a-cd7b-46f0-b3cf-79ee31887bf8	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301731P_EMI Board Cover 270	b1e5226b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:33:04.783111+01	2025-11-07 16:33:04.783111+01
85230358-c76b-4eb8-89b6-83acd31d9029	I10301731	50e52a71	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:33:10.635877+01	2025-11-07 16:33:10.635877+01
0f493510-a2be-4401-8c38-048c6678a551	I10301731	50e52a71	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:33:13.916197+01	2025-11-07 16:33:13.916197+01
c1ffe4fd-78c9-40bf-947a-fe149c504427	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301060P_Display Back 470/270	1ea38371	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:33:26.987232+01	2025-11-07 16:33:26.987232+01
08d7a9b3-72f0-443e-b96a-517227cbbce1	I10301060	dd78a852	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:33:38.817055+01	2025-11-07 16:33:38.817055+01
96e3938f-5386-472e-960f-3f2b5a98cc4f	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10401018R_Foot Rubber 470/430/270/230	8e95a69d	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:33:52.749779+01	2025-11-07 16:33:52.749779+01
35957e54-f14d-4080-90ab-2984c1a46790	I10401018	e7140410	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:34:53.452683+01	2025-11-07 16:34:53.452683+01
2f6c8182-b259-4cb9-912e-a8614f0dd006	I10401018	e7140410	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:34:58.052026+01	2025-11-07 16:34:58.052026+01
d4989bde-6740-468d-990f-c3a411673ad9	I10401045	dc668598	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:35:07.295524+01	2025-11-07 16:35:07.295524+01
82c1faf3-fea8-48f2-bca3-51a907da92e8	I10401045	dc668598	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:35:12.235578+01	2025-11-07 16:35:12.235578+01
dd404847-0d95-492e-97f1-93ec9f07fc21	I10401046	73cfc852	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:35:41.409305+01	2025-11-07 16:35:41.409305+01
0e133057-818e-4f66-92ba-dd0072584bea	I10401046	73cfc852	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:35:43.300507+01	2025-11-07 16:35:43.300507+01
be692c6d-658d-4597-91e1-e3c0b9cbbbdb	I10401046	73cfc852	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:35:55.544686+01	2025-11-07 16:35:55.544686+01
bedd05eb-8e7c-43b0-8668-a63a4caca507	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:36:11.053692+01	2025-11-07 16:36:11.053692+01
0bea3fbe-2c5f-4d85-a8d9-fcc89ba5f1f2	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:36:13.484431+01	2025-11-07 16:36:13.484431+01
47caded7-e15a-4a21-83a7-08ce4f8b2dba	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:36:17.835857+01	2025-11-07 16:36:17.835857+01
539c95f3-20cb-4219-b353-7b0d84a40e50	I8F905001	809e1e3b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:36:21.606131+01	2025-11-07 16:36:21.606131+01
e24c63c6-1fb8-40d8-86fa-759b616370aa	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:36:32.332729+01	2025-11-07 16:36:32.332729+01
6a148905-4ba1-4c2a-b453-5fb5326aa51a	I8F905001\r\n	f33579a0	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:36:46.6291+01	2025-11-07 16:36:46.6291+01
4d35fb81-f117-4a35-b618-34041c9c1751	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301293P_Key Display Number InBody270	c743ad27	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:37:19.045063+01	2025-11-07 16:37:19.045063+01
1f7b09b8-46a1-41a7-9a87-977e831fc34d	I10301293	1094a336	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:37:23.116293+01	2025-11-07 16:37:23.116293+01
a6703526-041b-4552-88e3-f976b4f36255	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101212Cable Hand R Black InBody270	c250d917	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:37:48.026696+01	2025-11-07 16:37:48.026696+01
68700f66-c69b-4c85-a97c-d9c14e315481	E01101211	ed275bdb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:37:55.321221+01	2025-11-07 16:37:55.321221+01
97868353-7880-4b22-a97e-7629a1ecc9c5	E01101211	ed275bdb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:37:58.979632+01	2025-11-07 16:37:58.979632+01
06a6d687-eed6-40ab-802c-16c3bc5ccb45	E01101211	ed275bdb	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:38:06.837005+01	2025-11-07 16:38:06.837005+01
8bcf77d9-d77a-4377-9935-9fa3a9d395b2	E01101212	428e1611	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:38:15.635889+01	2025-11-07 16:38:15.635889+01
05dcf34c-4b53-417a-b032-b74d7b8c4ab4	E01101212	428e1611	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:38:33.684853+01	2025-11-07 16:38:33.684853+01
bfd6c557-9842-4249-9f2e-0fa158bf08f0	E01101212	428e1611	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:38:37.203435+01	2025-11-07 16:38:37.203435+01
a02ed158-8aa3-4fe2-9f58-23bbf74f6422	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F920001Board LNO4 470/270	2359d22c	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:39:34.570292+01	2025-11-07 16:39:34.570292+01
93144288-5f91-43a0-8aa5-785b3182987f	I8F920001	c28a9973	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:39:39.082038+01	2025-11-07 16:39:39.082038+01
a5de87d2-d24d-41a9-9c3e-d89ea668d4a8	I8F920001	c28a9973	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:39:47.781596+01	2025-11-07 16:39:47.781596+01
7b574a92-a1d9-4b88-81a7-0e3218dd1273	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301570Electrode Foot S R 270/230	c544c8b7	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:39:53.012173+01	2025-11-07 16:39:53.012173+01
dc59833a-319b-4814-b5e5-d315767ee022	I10301570	092bdc0c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:07.280517+01	2025-11-07 16:40:07.280517+01
bd21aae4-0b2c-4437-bd9f-579c01fd850c	I10301568	0b2a8920	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:10.499676+01	2025-11-07 16:40:10.499676+01
ec447a27-8a16-461b-bca9-5cf664ef5d18	I10301569	6e4db266	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:14.812686+01	2025-11-07 16:40:14.812686+01
a487678b-36f5-424d-9ecc-09786aa9bb08	I10301569	6e4db266	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:20.523808+01	2025-11-07 16:40:20.523808+01
fcb6fe98-c1b2-4ddf-8094-9caed89fd29a	I10301567	77b5f901	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:22.813983+01	2025-11-07 16:40:22.813983+01
253039cd-ae61-4ab0-92f1-552c94fd0f6f	I10301567	77b5f901	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:26.054114+01	2025-11-07 16:40:26.054114+01
6eb75db4-2447-473b-b063-552e9da9af95	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I88118001Board Electrode 470/370/270	74df1208	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:40:38.551889+01	2025-11-07 16:40:38.551889+01
828b3280-d641-48f0-8a87-c8e9adf77c03	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:42.025869+01	2025-11-07 16:40:42.025869+01
c3807282-3f69-47f7-a04e-21c91f6cbfba	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:45.603847+01	2025-11-07 16:40:45.603847+01
b7f81b18-3434-4003-a526-e614e6361350	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:49.272722+01	2025-11-07 16:40:49.272722+01
d34102d5-9864-4b52-80d6-33a92b4fdcd5	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:51.842438+01	2025-11-07 16:40:51.842438+01
188707e5-4352-462d-9485-da12ea7751c1	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:55.518126+01	2025-11-07 16:40:55.518126+01
07a2b9a2-29f3-46a2-b8f0-35eca4136fdb	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:40:59.035619+01	2025-11-07 16:40:59.035619+01
d967f964-1fa0-4d10-8f45-511c98c0a372	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:02.842507+01	2025-11-07 16:41:02.842507+01
b9d4e83e-cb4d-4846-a759-1925b9ffbed6	I88118001	3d8c9c2d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:06.238189+01	2025-11-07 16:41:06.238189+01
0d179973-1111-433c-becf-a703671a5f89	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F820001Board LNO6 470/270	6721deed	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:41:12.840901+01	2025-11-07 16:41:12.840901+01
bbaa0e38-af75-4c85-9647-737b58d01709	I8F920002	6d23d4b9	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:15.974879+01	2025-11-07 16:41:15.974879+01
96c3bff5-5082-4606-bd84-e1f1c28c9061	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F813001Board Analog 470/270	3dba3350	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:41:23.675784+01	2025-11-07 16:41:23.675784+01
a7fe2958-5918-42ea-8a8c-cc5c6566d912	I8F813001	49fa9968	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:30.631263+01	2025-11-07 16:41:30.631263+01
d6c26797-7b69-4e91-be6e-7b4eeacec733	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101214Cable Foot 470/270 R	40a0a57b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:41:42.645809+01	2025-11-07 16:41:42.645809+01
07ced16e-1757-4ad8-a261-0e3d5e2e90c2	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:54.411805+01	2025-11-07 16:41:54.411805+01
512099b5-04c5-4ced-ad00-9d4c34e9d90a	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:41:58.462411+01	2025-11-07 16:41:58.462411+01
e57ce166-a8c8-4c96-a144-59362e5d28db	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:01.955212+01	2025-11-07 16:42:01.955212+01
ca59bbe3-b564-43ea-8b43-dce3e456b517	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:05.050354+01	2025-11-07 16:42:05.050354+01
237bd4d9-a754-439f-8f2b-9c4e3ce2e445	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:08.229943+01	2025-11-07 16:42:08.229943+01
c0b683d7-90d8-49c4-bb02-bb1c98d4fb62	E01101214\r\n	bd3c84df	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:11.047957+01	2025-11-07 16:42:11.047957+01
2a9b9348-de6b-4b3b-ac1a-62a2bfe9c110	E01101214\r\n	bd3c84df	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:14.946674+01	2025-11-07 16:42:14.946674+01
2d47131f-bc0c-4753-a66e-bc25ece3ccb4	E01101214\r\n	bd3c84df	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:17.940955+01	2025-11-07 16:42:17.940955+01
3ad011ff-1d6f-4833-89a6-35db6c461857	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:21.552788+01	2025-11-07 16:42:21.552788+01
cfdbd6eb-78c9-473e-b2fb-380634e68b07	E01101214	c6ad8bc4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:42:25.043437+01	2025-11-07 16:42:25.043437+01
6d90eb5f-e914-449d-975c-bbc357a9cd0c	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:10.592113+01	2025-11-07 16:43:10.592113+01
1adb334b-cad5-4568-a24b-3b1356795cc1	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:15.38247+01	2025-11-07 16:43:15.38247+01
9c5d9cb3-c424-48ee-9512-f17b74953a78	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:19.040813+01	2025-11-07 16:43:19.040813+01
63b6425b-55c2-41fc-8e08-0b911d9b851c	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:22.722459+01	2025-11-07 16:43:22.722459+01
d1a13cbf-7496-453d-8001-0641c8f7f103	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:26.421073+01	2025-11-07 16:43:26.421073+01
74f0a1a9-0dcb-4a36-81a9-145e59d1fd2d	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:28.282723+01	2025-11-07 16:43:28.282723+01
9022112d-ae41-4130-840b-2bb376b077ed	E01101213\r\n	8c24b3a8	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:33.539697+01	2025-11-07 16:43:33.539697+01
a697371c-32fd-4518-b721-993ba69db0be	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:36.940768+01	2025-11-07 16:43:36.940768+01
52bfe822-ed59-4364-a05c-7b110309929e	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:40.380295+01	2025-11-07 16:43:40.380295+01
00048c8b-6c0e-46eb-8f0b-131060d641fa	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:45.501157+01	2025-11-07 16:43:45.501157+01
514edc10-5227-4ff2-9e94-7eadea2a6394	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:49.382422+01	2025-11-07 16:43:49.382422+01
18452e1e-1f39-4a79-9be0-b5bffde61440	E01101213	27e92d57	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:43:53.321293+01	2025-11-07 16:43:53.321293+01
748fb8b3-f2d4-4da2-9233-e9d75b5d670b	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F921001Board Electrode Foot 470/270	189de30b	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:43:57.750614+01	2025-11-07 16:43:57.750614+01
bac28c1c-d0eb-4878-be57-bc9179ad84a7	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:07.668171+01	2025-11-07 16:44:07.668171+01
6d1fe095-037e-4ff7-a500-0a295ea04420	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:12.619324+01	2025-11-07 16:44:12.619324+01
2cb5670d-5b9f-44b8-bbe4-16b076087577	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:16.398257+01	2025-11-07 16:44:16.398257+01
36426249-17f2-44bd-818f-ec6e9118104a	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:20.42853+01	2025-11-07 16:44:20.42853+01
8b346f8a-f59c-4b14-9d04-f97370265fc3	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:24.452172+01	2025-11-07 16:44:24.452172+01
462ab378-ec0d-4c58-9c02-ab94e645a37d	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:28.160521+01	2025-11-07 16:44:28.160521+01
c81b7903-b736-4284-9519-4326beb4b714	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:31.901196+01	2025-11-07 16:44:31.901196+01
490b4489-a873-451c-a75b-115cdc5f3a30	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:36.450814+01	2025-11-07 16:44:36.450814+01
948cac80-22f5-4c6b-b4f4-2421ffb782eb	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:40.399838+01	2025-11-07 16:44:40.399838+01
0945f2d1-fb39-40a7-8483-fe483e4afd3e	I8F921001	59f973a7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:44.914836+01	2025-11-07 16:44:44.914836+01
361a1e4a-6fa4-4b0f-9314-83f1126c5736	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F910001Board IF 470/270	1657f842	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:44:53.54283+01	2025-11-07 16:44:53.54283+01
c49810e7-3610-4970-b3d8-c1f17e26fb7a	I8F910001	9a94305b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:44:59.050306+01	2025-11-07 16:44:59.050306+01
daa840c1-5774-4a86-95dd-e4eb985ba83d	I8F910001	9a94305b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:45:00.98184+01	2025-11-07 16:45:00.98184+01
4cad454e-55bc-4efd-babf-9a3293f50666	I8F910001	9a94305b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:45:05.452153+01	2025-11-07 16:45:05.452153+01
7f2977db-3b48-483e-a061-90c376e901b7	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301220P_Hand Lower 570/470/270	4cd25850	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:45:41.357378+01	2025-11-07 16:45:41.357378+01
19c1b6bc-71be-4b75-85c9-8ebdb8e3288f	I10301186	9dbc5df7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:45:49.46181+01	2025-11-07 16:45:49.46181+01
b8ff9e77-7470-4538-91dd-dc03f0fcb333	I10301186	9dbc5df7	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:45:53.134268+01	2025-11-07 16:45:53.134268+01
8787b32f-602b-4cac-8555-fc765c91cb07	I10301220	e1d16569	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:02.89325+01	2025-11-07 16:46:02.89325+01
1e5428c9-d999-49e7-bcfe-f9c13e9149b3	I10301220	e1d16569	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:05.287697+01	2025-11-07 16:46:05.287697+01
9dbd02d6-167c-4294-980b-d1486757849c	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301241P_Shoulder Back R 570/470/270	5957c2c2	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:46:14.392228+01	2025-11-07 16:46:14.392228+01
2f20de79-fa6c-4dbc-8992-e3b9c49651b0	I10301239\r\n	7162f2ab	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:16.745631+01	2025-11-07 16:46:16.745631+01
5d9260f4-3bb9-4e34-a569-cb20bbe5e5b3	I10301239\r\n	7162f2ab	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:24.533456+01	2025-11-07 16:46:24.533456+01
2546ce2a-d763-4040-9c4a-2989a6b16b19	I10301239\r\n	7162f2ab	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:41.239195+01	2025-11-07 16:46:41.239195+01
ee96852d-83eb-4ac1-9aea-cf4b4587e75f	I10301242	dd221623	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:46:48.933739+01	2025-11-07 16:46:48.933739+01
b3d857d9-7acc-45eb-8231-8909e2642f4a	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:50:24.056396+01	2025-11-07 16:50:24.056396+01
1ed41e48-229c-451b-b4d8-b6c9296c3200	I8P918001	0fa1f5b4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:50:28.479582+01	2025-11-07 16:50:28.479582+01
e3d040af-52fd-4401-9b55-c1fad56fab75	I8P918001	0fa1f5b4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:50:32.227221+01	2025-11-07 16:50:32.227221+01
aa153260-efea-440e-9da9-51f0da20ecb5	I8P918001	0fa1f5b4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:50:35.305551+01	2025-11-07 16:50:35.305551+01
366d6b7d-7eca-47b9-9af8-ded4b51b35c3	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:50:49.357918+01	2025-11-07 16:50:49.357918+01
4df7c2c9-6c2f-423d-a1f3-0706c855c6a2	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:50:58.697586+01	2025-11-07 16:50:58.697586+01
c4d15d8d-2cbf-4181-a02d-c1b62433ba4f	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:02.247508+01	2025-11-07 16:51:02.247508+01
9fe605a9-8b19-4c5e-99a1-67799f573253	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:07.246864+01	2025-11-07 16:51:07.246864+01
02823506-3d2b-481d-8931-a092959223c0	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:10.502484+01	2025-11-07 16:51:10.502484+01
67260d65-3627-40b9-9f7c-ea51e713db67	I8F905001 	961b3c1f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:12.76128+01	2025-11-07 16:51:12.76128+01
549e48e6-de24-4602-97a9-19f587bff53d	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301524Electrode Hand S 570/470/270	7154c629	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:51:26.089999+01	2025-11-07 16:51:26.089999+01
d51fc450-33d3-45b7-b1cf-10b2067706f3	I10301524	cae5b070	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:33.982295+01	2025-11-07 16:51:33.982295+01
078d2788-c365-4b84-8e7b-e39fcaea2ac2	I10301524	cae5b070	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:42.536561+01	2025-11-07 16:51:42.536561+01
3c7f6549-d616-4a14-b022-bdb4964efc49	I10301524	cae5b070	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:47.372613+01	2025-11-07 16:51:47.372613+01
4ecd39c1-3c64-475d-b23f-02d6dd97728e	I10301524	cae5b070	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:51:55.914877+01	2025-11-07 16:51:55.914877+01
cda6bad9-964d-451b-a82d-fa2a2bad800b	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D313001Board Analog 570/J10New	8001a7f5	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:52:01.673537+01	2025-11-07 16:52:01.673537+01
673897cd-d610-4da8-bdfc-e35538b6cd95	I8D313001	4556f7e3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:52:08.196327+01	2025-11-07 16:52:08.196327+01
4118ca2a-9691-40bd-9ac6-da2f1f3a68de	I8D313001	4556f7e3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:52:12.184728+01	2025-11-07 16:52:12.184728+01
914e9ce2-8fb7-415a-93f4-d542076d84fc	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D313001Board Analog 570/J10New	8001a7f5	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:58:06.795337+01	2025-11-07 16:58:06.795337+01
90723111-eb65-4b20-9a53-c3f466e65a15	I8D313001	4556f7e3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:58:23.089018+01	2025-11-07 16:58:23.089018+01
a27f409a-8ba6-41ec-ba0f-b911fe590146	I8D313001	4556f7e3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:58:29.244491+01	2025-11-07 16:58:29.244491+01
fc8c21c1-4554-4950-956b-44d25b6b4a1f	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8G605001LCD Touch 570/370/S10	caf147e1	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 16:59:29.706088+01	2025-11-07 16:59:29.706088+01
83b8a67a-8667-4d9e-a403-6f7f3762f2e3	I8G605001	85d8d7b3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:59:32.889586+01	2025-11-07 16:59:32.889586+01
2cfd06ec-df01-4d38-b6cd-0a66e8948e31	I8G605001	85d8d7b3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:59:36.57478+01	2025-11-07 16:59:36.57478+01
53cab27c-56c9-4499-9dbd-a7e4d4053d4a	I8G605001	85d8d7b3	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:59:39.648256+01	2025-11-07 16:59:39.648256+01
11d81f86-6452-4546-abb8-be90a9a11869	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 16:59:55.107044+01	2025-11-07 16:59:55.107044+01
523ae532-3efe-4a57-b7a6-c2c2088f15bb	I8P999001	46df23de	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 16:59:58.214739+01	2025-11-07 16:59:58.214739+01
227ba176-cfdb-4963-be0c-2042638c11be	I8P999001	46df23de	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:00.73363+01	2025-11-07 17:00:00.73363+01
310234b0-4725-440b-9a20-ae56571ce3f3	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:00:06.447092+01	2025-11-07 17:00:06.447092+01
49b4d74c-b98a-4aec-99f8-c950adfffd56	I10301844	ce126476	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:22.822493+01	2025-11-07 17:00:22.822493+01
84b234d7-ccea-4a2b-92d7-770d371c8c20	I10301844	ce126476	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:25.426869+01	2025-11-07 17:00:25.426869+01
a9264283-25ee-4b2d-bef9-5c97c679edd7	I10301844	ce126476	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:28.498034+01	2025-11-07 17:00:28.498034+01
72048239-bdae-49fa-b310-be2238dea068	I10301844	ce126476	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:31.493141+01	2025-11-07 17:00:31.493141+01
fb40d17b-9883-4170-8663-06f59e4b5137	I10301843	2f56c2e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:34.325041+01	2025-11-07 17:00:34.325041+01
dd15d6f3-3ea6-42fe-9fd3-5388f0174620	I10301843	2f56c2e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:37.667682+01	2025-11-07 17:00:37.667682+01
fac1e277-52d5-4167-a8ea-f14cfb3f2348	I10301843	2f56c2e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:40.692233+01	2025-11-07 17:00:40.692233+01
0ee5348f-20cd-4fca-92ba-d7124f04904d	I10301843	2f56c2e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:00:44.616327+01	2025-11-07 17:00:44.616327+01
99cc347a-4c24-4309-90ea-5bf770a7163f	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301097P_Foot Case Cover 570/520	85ba8818	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:00:53.554046+01	2025-11-07 17:00:53.554046+01
ef8af755-8087-4062-9271-1c05bde3ce07	I10301097	702981ef	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:00.71378+01	2025-11-07 17:01:00.71378+01
b639e2fe-1af5-433c-ab75-b00ccc43a0ad	I10301097	702981ef	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:03.305265+01	2025-11-07 17:01:03.305265+01
071988de-fa8b-492c-b0a8-83db10408b9f	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D325001Board Key 570 KNO4	9e0d436a	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:01:09.257571+01	2025-11-07 17:01:09.257571+01
eaebc44a-c00c-4d56-ad8c-7f56c7182e77	I10301625	96fa2676	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:17.296791+01	2025-11-07 17:01:17.296791+01
b151a63c-c398-4970-9d54-eec71445ccbe	I8D325001	f0822cb1	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:20.734779+01	2025-11-07 17:01:20.734779+01
aabde97d-eb97-4f70-bf99-bb0f0af32bcb	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8G621001Board Electrode 570	22894725	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:01:29.117282+01	2025-11-07 17:01:29.117282+01
d50c634b-4dd4-40ca-a6bc-01c58e39ed95	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:36.616084+01	2025-11-07 17:01:36.616084+01
df7d466a-a0ed-459f-ad12-2f41843d5e39	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:41.907012+01	2025-11-07 17:01:41.907012+01
2c113509-8bab-4153-bb83-495889f583c6	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:45.811092+01	2025-11-07 17:01:45.811092+01
3004a7dd-b0a5-46e2-a29f-c269f64aeb62	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:49.312078+01	2025-11-07 17:01:49.312078+01
43e9ad57-6b43-4364-afa4-4e862be02260	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:53.559418+01	2025-11-07 17:01:53.559418+01
427eebf8-b5d1-4f68-9b0b-0a19b7bbdd5e	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:01:57.901047+01	2025-11-07 17:01:57.901047+01
04fea89c-d214-419b-b60b-2d1511d5f728	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:01.494044+01	2025-11-07 17:02:01.494044+01
299753a4-5ab8-41a9-ba58-83195be9913d	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:05.603314+01	2025-11-07 17:02:05.603314+01
87bdbce4-2321-4657-a1dd-f003a283529a	I8G621001	5cbfba2f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:10.142481+01	2025-11-07 17:02:10.142481+01
7b929c50-1713-4d4c-99ec-1abf4ed5ab4b	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:02:18.752006+01	2025-11-07 17:02:18.752006+01
f29f872b-469b-4edd-8500-4ec2c76551d2	E01101152	690fbfea	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:29.340807+01	2025-11-07 17:02:29.340807+01
8d1b069c-3128-45e5-984b-33c234c04e28	E01101152	690fbfea	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:32.973789+01	2025-11-07 17:02:32.973789+01
d07ed718-55e1-4ed4-a2b7-b57a058886f9	E01101152\r\n	04eb718c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:36.180076+01	2025-11-07 17:02:36.180076+01
f8ebf426-098e-473b-a772-7129dbe18242	E01101152	690fbfea	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:40.594247+01	2025-11-07 17:02:40.594247+01
db8241f3-d898-4e5d-83cb-3b38f13ae2a6	E01101151	c6a6f220	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:44.898778+01	2025-11-07 17:02:44.898778+01
ac8256d3-fe3b-4c7a-8c1e-bf7da2afcabe	E01101151	c6a6f220	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:47.967332+01	2025-11-07 17:02:47.967332+01
fec2b063-3c1d-4f45-96ff-d603c8c37400	E01101151	c6a6f220	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:50.726369+01	2025-11-07 17:02:50.726369+01
24782445-ed50-4855-a2a6-035f96008f0b	E01101151	c6a6f220	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:02:54.064798+01	2025-11-07 17:02:54.064798+01
808feacc-4db8-435e-b076-452ba04e6f5d	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:03:03.483313+01	2025-11-07 17:03:03.483313+01
3e2008d3-8dd9-4f4d-be87-1af7546f9525	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:13.513626+01	2025-11-07 17:03:13.513626+01
7b6a8364-2614-4c33-bd77-f66ce5e9f357	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:17.573199+01	2025-11-07 17:03:17.573199+01
480b8bdd-f5bd-47f3-9132-70194736600d	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:20.794395+01	2025-11-07 17:03:20.794395+01
bdd67c41-0971-4000-82db-c01ddec10509	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:23.76904+01	2025-11-07 17:03:23.76904+01
28c390a0-ccb0-4d6a-92d9-63cd662f5223	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:26.598221+01	2025-11-07 17:03:26.598221+01
14461068-e8e3-4c81-9be8-be7ac5977e9c	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:29.429504+01	2025-11-07 17:03:29.429504+01
e2c640b8-e6e1-4822-b781-442e20d96b30	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:32.439344+01	2025-11-07 17:03:32.439344+01
f7c10692-df55-4f6d-b4e6-6b60edcad297	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:35.876166+01	2025-11-07 17:03:35.876166+01
c3e1b365-062c-4108-a528-b453c45a30ea	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:41.251581+01	2025-11-07 17:03:41.251581+01
dae2a386-95da-4dcb-94fd-e913c6946d38	I8G621002	f316f7e5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:03:45.908122+01	2025-11-07 17:03:45.908122+01
ac9d8b17-3c36-4467-82b2-1a649f968197	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301547Electrode Foot B 570/520	651b00ba	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:03:56.130321+01	2025-11-07 17:03:56.130321+01
8c028994-6246-4187-9faf-1938485cd427	I10301547	9371f87c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:04:05.210872+01	2025-11-07 17:04:05.210872+01
2a5564a6-0a0b-4c65-80d6-31ee40a3572a	I10301548	efee885d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:04:16.468956+01	2025-11-07 17:04:16.468956+01
ee6a6406-48a7-4b09-be39-af9f5944ff83	I10301548	efee885d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:04:21.367847+01	2025-11-07 17:04:21.367847+01
5b9d9681-477f-4ef1-b141-5dee07a25e66	I10301548	efee885d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:04:25.926346+01	2025-11-07 17:04:25.926346+01
0a93e6a7-9228-4440-8ea3-b513e70f5eca	I10301548	efee885d	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:04:28.966758+01	2025-11-07 17:04:28.966758+01
4da6029e-7e26-4b67-8346-ff7f4b726f0a	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10201098M_Hand Pipe 570	a2bee5a5	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:04:42.9818+01	2025-11-07 17:04:42.9818+01
bfac2af3-da5d-48c7-8083-93290f1a72a0	I10201098	a93d61c0	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:04.048848+01	2025-11-07 17:05:04.048848+01
a04f81b5-c596-4f82-984f-c0d540c37085	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101153Cable Foot 570/520 L Blue	f4d23a21	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:05:22.339654+01	2025-11-07 17:05:22.339654+01
b5b7af51-f8c2-4a21-875f-8a6c541e2743	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:30.510095+01	2025-11-07 17:05:30.510095+01
304f551a-bb70-42ec-a9ee-2cddafd97780	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:33.866818+01	2025-11-07 17:05:33.866818+01
ee053aae-a0d6-4dca-84c0-e6598d9639de	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:37.039913+01	2025-11-07 17:05:37.039913+01
e308f313-2ac0-4386-9887-1bf4a2a50e4d	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:40.630237+01	2025-11-07 17:05:40.630237+01
5bf02aa7-35d8-4d23-adf5-5c28da0e9471	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:43.63689+01	2025-11-07 17:05:43.63689+01
7e167b3b-6672-45e6-9c03-b26006b4127a	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:46.822895+01	2025-11-07 17:05:46.822895+01
5db12d49-6618-4e4c-b47a-269f24444b62	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:50.883713+01	2025-11-07 17:05:50.883713+01
e3adbdb1-58b4-4f95-95c8-a57a9525af4c	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:54.0295+01	2025-11-07 17:05:54.0295+01
dd643cea-7ab2-4a28-b26c-895f07331239	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:05:57.762057+01	2025-11-07 17:05:57.762057+01
19a68f12-13f6-4a35-be9c-ba171ec2cae4	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:09.127109+01	2025-11-07 17:06:09.127109+01
e070df84-527c-406b-9074-4ddab338bb2f	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:11.948105+01	2025-11-07 17:06:11.948105+01
23b3eff2-7d3a-44b6-8fd4-bbbe5b34ed51	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:14.62127+01	2025-11-07 17:06:14.62127+01
838ea7f8-57cc-42a2-8a5b-5e08102c8f3d	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:17.507549+01	2025-11-07 17:06:17.507549+01
129ae4b6-f263-4dcf-a87c-c1b5f37b9b46	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:20.620996+01	2025-11-07 17:06:20.620996+01
d6c61cbd-305b-4960-abc0-d568be512d5a	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:23.613336+01	2025-11-07 17:06:23.613336+01
b6936e12-ac2d-45f7-88d1-d5cdb93813da	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:27.024847+01	2025-11-07 17:06:27.024847+01
31cbb26f-6175-4e3e-9e91-959b32192710	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:31.170925+01	2025-11-07 17:06:31.170925+01
688406d8-93d2-41f8-8ea9-a1d882c73685	E01101153	0c6884ac	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:53.002568+01	2025-11-07 17:06:53.002568+01
ece84564-2af9-4588-8cad-a69141cfbced	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:56.395705+01	2025-11-07 17:06:56.395705+01
8383aef8-9c20-4c9f-91c8-1e4b909fe81c	E01101154	ed2c223f	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:06:58.916324+01	2025-11-07 17:06:58.916324+01
7b8b3ef5-3fe8-46d1-89b9-6f33210dbc5b	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:07:25.90825+01	2025-11-07 17:07:25.90825+01
2229f4a4-49dc-4bb1-aa08-439d134ebb97	I10301155	9ac49e6e	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:07:33.240754+01	2025-11-07 17:07:33.240754+01
f1600329-31c3-452d-979a-83378ff86506	I10301155	9ac49e6e	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:07:36.430119+01	2025-11-07 17:07:36.430119+01
c0c6dc23-fe15-40ab-89ca-39867c3f0db9	I10301155	9ac49e6e	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:07:38.663151+01	2025-11-07 17:07:38.663151+01
890c8481-7017-424a-9edb-5b53133e683e	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I88120001[Not in use] Board LNO1 370/210/S10	52e4bb8c	ac8ee24e54707128	\N	QRCODE	0	buffered	2025-11-07 17:07:49.786159+01	2025-11-07 17:07:49.786159+01
26c7969c-b2dd-4fe1-bde4-775f92ef3e4b	I88120001	652b7623	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:08:11.924572+01	2025-11-07 17:08:11.924572+01
f4b1ec76-5f98-4cae-9c9f-90e205b605a5	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:08:37.352477+01	2025-11-07 17:08:37.352477+01
ab7978cc-85da-4c7b-a05b-72ed56ef9697	I10301871	9e86368a	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:08:46.988594+01	2025-11-07 17:08:46.988594+01
74a1b9e0-f695-4bd4-b3fc-31bf7a951c8c	I10301871	9e86368a	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:08:54.407585+01	2025-11-07 17:08:54.407585+01
c1163b1e-5985-4ce3-b1e3-464fc0c6aa5f	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:08:59.121059+01	2025-11-07 17:08:59.121059+01
f15cffa7-330d-40b0-b7eb-7bc887536337	I10301838	74c3dfc5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:12.331616+01	2025-11-07 17:09:12.331616+01
c96d74c2-0b95-4097-b2c4-dccc751c4501	I10301838	74c3dfc5	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:22.369195+01	2025-11-07 17:09:22.369195+01
9c6ea1d4-d730-482b-b6cb-36d2f3b8113f	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:09:26.811033+01	2025-11-07 17:09:26.811033+01
bbd9dd53-58a7-406c-9f49-df0ce1c43630	I10301859	e799e145	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:33.653025+01	2025-11-07 17:09:33.653025+01
bf1aaf7b-2742-4db4-80f3-df705ddece14	I10301859	e799e145	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:35.962593+01	2025-11-07 17:09:35.962593+01
41409257-abf0-4e2e-b973-65aafe5162e6	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:09:43.510838+01	2025-11-07 17:09:43.510838+01
226b6a31-9c01-4587-97ad-4374506b64f9	I10301805	b98c5b8b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:50.896657+01	2025-11-07 17:09:50.896657+01
f7d6f61a-98f6-4834-9318-01e79bb08fac	I10301805	b98c5b8b	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:09:59.709042+01	2025-11-07 17:09:59.709042+01
d56c5741-ddd4-44ae-85d9-cad64b016e9d	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:10:13.303044+01	2025-11-07 17:10:13.303044+01
c2369f6b-0498-4e69-90e9-c56179ee7535	I8R632001	cca48d04	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:13:03.608296+01	2025-11-07 17:13:03.608296+01
62edc5ca-369d-4b2b-ae1c-ba558eab1ece	I8R632001	cca48d04	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:13:06.119676+01	2025-11-07 17:13:06.119676+01
aab03552-84cc-4eef-b0c1-c833c368e760	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:14:53.410676+01	2025-11-07 17:14:53.410676+01
cc77dada-a611-4f74-8ad2-ba264ce52f8c	I8P925001	cc2954fd	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:14:56.533442+01	2025-11-07 17:14:56.533442+01
c19ee571-204c-4d78-a571-8d7f90f7121c	I8P925001	cc2954fd	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:00.188647+01	2025-11-07 17:15:00.188647+01
32d8664b-5bc2-4cda-853f-55501d6520cd	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:15:09.551044+01	2025-11-07 17:15:09.551044+01
598a3ab5-b192-4bc2-bb3d-47bdb3f0429d	I8P920001	57061fba	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:12.164169+01	2025-11-07 17:15:12.164169+01
e9092dab-d70f-484b-b594-fd6a5ec6ee1a	I8P920001	57061fba	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:14.992877+01	2025-11-07 17:15:14.992877+01
89454525-0da3-4e34-be1e-dfccb949d137	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:15:25.737082+01	2025-11-07 17:15:25.737082+01
fc1f1977-5a29-4a3b-92b8-86b1ca28e99d	I10301837	085cafe4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:50.421309+01	2025-11-07 17:15:50.421309+01
1e9f51b6-f53f-47d3-b9aa-8bf7e48e7b0b	I10301837	085cafe4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:55.489787+01	2025-11-07 17:15:55.489787+01
bd767cda-9821-4b0e-8d5e-75405ddd8803	I10301837	085cafe4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:15:58.989039+01	2025-11-07 17:15:58.989039+01
8abd6cb5-f05a-4dbe-9750-40178277dc53	I10301837	085cafe4	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:02.690591+01	2025-11-07 17:16:02.690591+01
be739ca3-53b6-440d-8571-400fd2b23429	I10301836	6d3b94a2	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:08.697943+01	2025-11-07 17:16:08.697943+01
80422b80-eb53-4411-ba2c-96226d55d2f2	I10301836	6d3b94a2	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:11.701445+01	2025-11-07 17:16:11.701445+01
62e32f5c-a054-4d42-970d-9908cfe7bcac	I10301836	6d3b94a2	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:14.522775+01	2025-11-07 17:16:14.522775+01
f9029996-ccf8-4738-b5d6-f62da6d674ad	I10301836	6d3b94a2	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:17.432707+01	2025-11-07 17:16:17.432707+01
012c4c97-399a-4332-b24c-85bb83ac1e57	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:16:28.968618+01	2025-11-07 17:16:28.968618+01
0a9426b6-004b-4be3-ba36-86e97c4011f3	I10301806	16251641	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:16:32.780168+01	2025-11-07 17:16:32.780168+01
af24a782-5476-4f48-b776-717f902d1e42	5412386058608	614e2a61	ac8ee24e54707128	\N	EAN-13	0	buffered	2025-11-07 17:16:39.882674+01	2025-11-07 17:16:39.882674+01
c71d93ca-90ab-4442-87c1-33c0af6c4438	I10301822	bc0cfc65	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:26.970826+01	2025-11-07 17:17:26.970826+01
c857674e-c4dd-48a2-8de1-d06c5d3fd0aa	I10301822	bc0cfc65	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:32.914096+01	2025-11-07 17:17:32.914096+01
8ff0550c-c3b1-48bb-8139-02ee0461c358	I10301822	bc0cfc65	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:36.017963+01	2025-11-07 17:17:36.017963+01
01729664-3c26-4e41-9fa4-ae3213adc208	I10301822	bc0cfc65	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:38.922241+01	2025-11-07 17:17:38.922241+01
8c824111-8c74-45db-bd67-8de104d26c2b	I10301826	f2e1173c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:51.686235+01	2025-11-07 17:17:51.686235+01
d0a50e44-f1cd-47f8-b293-74cefec1d0db	I10301826	f2e1173c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:54.76691+01	2025-11-07 17:17:54.76691+01
25999e8b-2f29-453d-8610-f639681b5a6e	I10301826	f2e1173c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:17:58.973002+01	2025-11-07 17:17:58.973002+01
c17a4fd8-24ba-4b2f-b7ca-f20ac1e0d6ce	I10301826	f2e1173c	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:18:01.874387+01	2025-11-07 17:18:01.874387+01
e659f19e-a560-4a22-921e-aafbac808ee2	I10301825	5d485af6	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:18:11.745172+01	2025-11-07 17:18:11.745172+01
dd82d0a3-e1ed-46e7-8e79-6f60e71c245b	I10301825	5d485af6	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:18:14.286818+01	2025-11-07 17:18:14.286818+01
db6fb862-462e-4458-b4b4-b7095fdb897a	I10301825	5d485af6	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:18:17.000739+01	2025-11-07 17:18:17.000739+01
c55ef117-0778-4bac-9f3c-8ea1ffc55818	I10301825	5d485af6	ac8ee24e54707128	\N	Code128	0	buffered	2025-11-07 17:18:20.936737+01	2025-11-07 17:18:20.936737+01
\.


--
-- Data for Name: scans_backup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scans_backup (id, payload, checksum, "deviceId", type, priority, status, "createdAt", "updatedAt", repair_order_id) FROM stdin;
1	image-1762509641300-146283010.webp	ce5884b0	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:00:41.367613+01	2025-11-07 11:00:41.367613+01	\N
2	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 11:02:20.614825+01	2025-11-07 11:02:20.614825+01	\N
3	TEST-BARCODE-123	\N	test-device	scanner	0	buffered	2025-11-07 11:02:46.576879+01	2025-11-07 11:02:46.576879+01	\N
4	DUSFRA6Z04194045192501	cd437510	ac8ee24e54707128	Code128	0	buffered	2025-11-07 11:17:19.413734+01	2025-11-07 11:17:19.413734+01	\N
5	TXLFRA0J04194044806901	bbcd5a18	ac8ee24e54707128	Code128	0	buffered	2025-11-07 11:40:12.052707+01	2025-11-07 11:40:12.052707+01	\N
6	image-1762512043524-500453134.webp	02ca67e2	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:40:43.596815+01	2025-11-07 11:40:43.596815+01	\N
7	image-1762512110620-857259731.webp	dbf34fd9	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:41:50.710744+01	2025-11-07 11:41:50.710744+01	\N
8	F91704219	2ed86064	ac8ee24e54707128	Code128	0	buffered	2025-11-07 11:41:54.434825+01	2025-11-07 11:41:54.434825+01	\N
9	F91704219	340cd5e7	ac8ee24e54707128	CODE_128	0	buffered	2025-11-07 11:42:30.843014+01	2025-11-07 11:42:30.843014+01	\N
10	F91704219	340cd5e7	ac8ee24e54707128	CODE_128	0	buffered	2025-11-07 11:43:00.994946+01	2025-11-07 11:43:00.994946+01	\N
11	F91704219	2ed86064	ac8ee24e54707128	Code128	0	buffered	2025-11-07 11:43:19.897662+01	2025-11-07 11:43:19.897662+01	\N
12	image-1762512301123-527360661.webp	e8d9bc15	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:45:01.207781+01	2025-11-07 11:45:01.207781+01	\N
13	image-1762512357081-39446633.webp	dae21b84	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:45:57.179885+01	2025-11-07 11:45:57.179885+01	\N
14	image-1762512705705-424048410.webp	3138dfae	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:51:45.807393+01	2025-11-07 11:51:45.807393+01	\N
15	image-1762512733857-80549889.webp	4646ef96	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:52:13.932832+01	2025-11-07 11:52:13.932832+01	\N
16	image-1762512742818-291102075.webp	6c99152b	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:52:22.884027+01	2025-11-07 11:52:22.884027+01	\N
17	image-1762512762096-221205998.webp	c969a9b9	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:52:42.208474+01	2025-11-07 11:52:42.208474+01	\N
18	image-1762512793795-446607352.webp	fab03682	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:53:13.863625+01	2025-11-07 11:53:13.863625+01	\N
19	image-1762512821206-297654870.webp	659dbe5e	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 11:53:41.305607+01	2025-11-07 11:53:41.305607+01	\N
20	OCU998503628	f0015117	ac8ee24e54707128	Code128	0	buffered	2025-11-07 11:59:17.087412+01	2025-11-07 11:59:17.087412+01	\N
21	image-1762523418976-816141001.webp	a09a506b	ac8ee24e54707128	direct_upload	0	uploaded	2025-11-07 14:50:19.013439+01	2025-11-07 14:50:19.013439+01	\N
22	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 14:56:54.728561+01	2025-11-07 14:56:54.728561+01	\N
23	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 14:57:10.328741+01	2025-11-07 14:57:10.328741+01	\N
24	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 14:57:15.326677+01	2025-11-07 14:57:15.326677+01	\N
25	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 14:57:18.234778+01	2025-11-07 14:57:18.234778+01	\N
26	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:03:51.21727+01	2025-11-07 15:03:51.21727+01	\N
27	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:03:56.133123+01	2025-11-07 15:03:56.133123+01	\N
28	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:06:14.917643+01	2025-11-07 15:06:14.917643+01	\N
29	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:06:17.545064+01	2025-11-07 15:06:17.545064+01	\N
30	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:10:19.186659+01	2025-11-07 15:10:19.186659+01	\N
31	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:10:29.08171+01	2025-11-07 15:10:29.08171+01	\N
32	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:10:32.878652+01	2025-11-07 15:10:32.878652+01	\N
33	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:38:09.749643+01	2025-11-07 15:38:09.749643+01	\N
34	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:36.04456+01	2025-11-07 15:40:36.04456+01	\N
35	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:38.229639+01	2025-11-07 15:40:38.229639+01	\N
36	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:41.527212+01	2025-11-07 15:40:41.527212+01	\N
37	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:44.027334+01	2025-11-07 15:40:44.027334+01	\N
38	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:53.054042+01	2025-11-07 15:40:53.054042+01	\N
39	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:40:55.87245+01	2025-11-07 15:40:55.87245+01	\N
40	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:04.82067+01	2025-11-07 15:41:04.82067+01	\N
41	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:08.452536+01	2025-11-07 15:41:08.452536+01	\N
42	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:10.830169+01	2025-11-07 15:41:10.830169+01	\N
43	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:13.492061+01	2025-11-07 15:41:13.492061+01	\N
44	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:31.479764+01	2025-11-07 15:41:31.479764+01	\N
45	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:34.548163+01	2025-11-07 15:41:34.548163+01	\N
46	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:37.29442+01	2025-11-07 15:41:37.29442+01	\N
47	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:41:39.456106+01	2025-11-07 15:41:39.456106+01	\N
48	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:49:01.168407+01	2025-11-07 15:49:01.168407+01	\N
49	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:49:07.038561+01	2025-11-07 15:49:07.038561+01	\N
50	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:49:09.464173+01	2025-11-07 15:49:09.464173+01	\N
51	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:49:12.353655+01	2025-11-07 15:49:12.353655+01	\N
52	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:49:14.516937+01	2025-11-07 15:49:14.516937+01	\N
53	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:56:26.494702+01	2025-11-07 15:56:26.494702+01	\N
54	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:56:30.046939+01	2025-11-07 15:56:30.046939+01	\N
55	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:56:42.666303+01	2025-11-07 15:56:42.666303+01	\N
56	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 15:56:45.254001+01	2025-11-07 15:56:45.254001+01	\N
57	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:00:45.090106+01	2025-11-07 16:00:45.090106+01	\N
58	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:00:47.357332+01	2025-11-07 16:00:47.357332+01	\N
59	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:03:56.260457+01	2025-11-07 16:03:56.260457+01	\N
60	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:03:58.446526+01	2025-11-07 16:03:58.446526+01	\N
61	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:04:59.126668+01	2025-11-07 16:04:59.126668+01	\N
62	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:05:01.724621+01	2025-11-07 16:05:01.724621+01	\N
63	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:06:40.713842+01	2025-11-07 16:06:40.713842+01	\N
64	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:06:45.596875+01	2025-11-07 16:06:45.596875+01	\N
65	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:09:05.672079+01	2025-11-07 16:09:05.672079+01	\N
66	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:09:08.801416+01	2025-11-07 16:09:08.801416+01	\N
67	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:09:11.088049+01	2025-11-07 16:09:11.088049+01	\N
68	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:09:14.408648+01	2025-11-07 16:09:14.408648+01	\N
69	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:09:39.036469+01	2025-11-07 16:09:39.036469+01	\N
70	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:09:44.569505+01	2025-11-07 16:09:44.569505+01	\N
71	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:09:49.903477+01	2025-11-07 16:09:49.903477+01	\N
72	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:10:09.622071+01	2025-11-07 16:10:09.622071+01	\N
73	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F920001Board LNO4 470/270	2359d22c	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:10:52.43172+01	2025-11-07 16:10:52.43172+01	\N
74	I8F920001	c28a9973	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:10:56.208909+01	2025-11-07 16:10:56.208909+01	\N
75	I8F920001	c28a9973	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:11:11.2192+01	2025-11-07 16:11:11.2192+01	\N
76	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:27:25.998063+01	2025-11-07 16:27:25.998063+01	\N
77	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:27:27.659581+01	2025-11-07 16:27:27.659581+01	\N
78	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:27:36.18849+01	2025-11-07 16:27:36.18849+01	\N
79	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301732P_Display Back EMI 470/270	b4723ba2	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:28:57.568946+01	2025-11-07 16:28:57.568946+01	\N
80	I10301732	ff4c67bb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:29:11.006451+01	2025-11-07 16:29:11.006451+01	\N
81	I10301732	ff4c67bb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:29:13.715711+01	2025-11-07 16:29:13.715711+01	\N
82	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301733P_Display Front New EMI 470/270	128fd0f7	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:29:32.565826+01	2025-11-07 16:29:32.565826+01	\N
83	I10301733	9a2b5cfd	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:29:35.828991+01	2025-11-07 16:29:35.828991+01	\N
84	I10301733	9a2b5cfd	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:29:38.583106+01	2025-11-07 16:29:38.583106+01	\N
85	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301653P_Display Front New 470/270	bcc82b18	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:29:49.877229+01	2025-11-07 16:29:49.877229+01	\N
86	I10301653	7b3e3dfb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:29:59.355137+01	2025-11-07 16:29:59.355137+01	\N
87	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301652P_Bezel New 270	4e31e1a1	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:30:08.207129+01	2025-11-07 16:30:08.207129+01	\N
88	I10301652	1e5906bd	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:30:10.48294+01	2025-11-07 16:30:10.48294+01	\N
89	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301455P_Shoulder Cap 470/270	109762a6	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:30:20.395204+01	2025-11-07 16:30:20.395204+01	\N
90	I10301455	d14d69ae	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:30:46.797133+01	2025-11-07 16:30:46.797133+01	\N
91	I10301455	d14d69ae	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:30:49.240752+01	2025-11-07 16:30:49.240752+01	\N
92	I10301455	d14d69ae	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:30:52.357096+01	2025-11-07 16:30:52.357096+01	\N
93	I10301455	d14d69ae	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:32:41.272221+01	2025-11-07 16:32:41.272221+01	\N
94	I10301455	d14d69ae	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:32:43.64799+01	2025-11-07 16:32:43.64799+01	\N
95	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301731P_EMI Board Cover 270	b1e5226b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:33:04.783111+01	2025-11-07 16:33:04.783111+01	\N
96	I10301731	50e52a71	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:33:10.635877+01	2025-11-07 16:33:10.635877+01	\N
97	I10301731	50e52a71	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:33:13.916197+01	2025-11-07 16:33:13.916197+01	\N
98	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301060P_Display Back 470/270	1ea38371	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:33:26.987232+01	2025-11-07 16:33:26.987232+01	\N
99	I10301060	dd78a852	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:33:38.817055+01	2025-11-07 16:33:38.817055+01	\N
100	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10401018R_Foot Rubber 470/430/270/230	8e95a69d	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:33:52.749779+01	2025-11-07 16:33:52.749779+01	\N
101	I10401018	e7140410	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:34:53.452683+01	2025-11-07 16:34:53.452683+01	\N
102	I10401018	e7140410	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:34:58.052026+01	2025-11-07 16:34:58.052026+01	\N
103	I10401045	dc668598	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:35:07.295524+01	2025-11-07 16:35:07.295524+01	\N
104	I10401045	dc668598	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:35:12.235578+01	2025-11-07 16:35:12.235578+01	\N
105	I10401046	73cfc852	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:35:41.409305+01	2025-11-07 16:35:41.409305+01	\N
106	I10401046	73cfc852	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:35:43.300507+01	2025-11-07 16:35:43.300507+01	\N
107	I10401046	73cfc852	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:35:55.544686+01	2025-11-07 16:35:55.544686+01	\N
108	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F905001LCD Touch 470/270/370S	b44f8f0b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:36:11.053692+01	2025-11-07 16:36:11.053692+01	\N
109	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:36:13.484431+01	2025-11-07 16:36:13.484431+01	\N
110	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:36:17.835857+01	2025-11-07 16:36:17.835857+01	\N
111	I8F905001	809e1e3b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:36:21.606131+01	2025-11-07 16:36:21.606131+01	\N
112	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:36:32.332729+01	2025-11-07 16:36:32.332729+01	\N
113	I8F905001\r\n	f33579a0	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:36:46.6291+01	2025-11-07 16:36:46.6291+01	\N
114	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301293P_Key Display Number InBody270	c743ad27	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:37:19.045063+01	2025-11-07 16:37:19.045063+01	\N
115	I10301293	1094a336	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:37:23.116293+01	2025-11-07 16:37:23.116293+01	\N
116	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101212Cable Hand R Black InBody270	c250d917	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:37:48.026696+01	2025-11-07 16:37:48.026696+01	\N
117	E01101211	ed275bdb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:37:55.321221+01	2025-11-07 16:37:55.321221+01	\N
118	E01101211	ed275bdb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:37:58.979632+01	2025-11-07 16:37:58.979632+01	\N
119	E01101211	ed275bdb	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:38:06.837005+01	2025-11-07 16:38:06.837005+01	\N
120	E01101212	428e1611	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:38:15.635889+01	2025-11-07 16:38:15.635889+01	\N
121	E01101212	428e1611	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:38:33.684853+01	2025-11-07 16:38:33.684853+01	\N
122	E01101212	428e1611	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:38:37.203435+01	2025-11-07 16:38:37.203435+01	\N
123	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F920001Board LNO4 470/270	2359d22c	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:39:34.570292+01	2025-11-07 16:39:34.570292+01	\N
124	I8F920001	c28a9973	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:39:39.082038+01	2025-11-07 16:39:39.082038+01	\N
125	I8F920001	c28a9973	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:39:47.781596+01	2025-11-07 16:39:47.781596+01	\N
126	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301570Electrode Foot S R 270/230	c544c8b7	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:39:53.012173+01	2025-11-07 16:39:53.012173+01	\N
127	I10301570	092bdc0c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:07.280517+01	2025-11-07 16:40:07.280517+01	\N
128	I10301568	0b2a8920	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:10.499676+01	2025-11-07 16:40:10.499676+01	\N
129	I10301569	6e4db266	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:14.812686+01	2025-11-07 16:40:14.812686+01	\N
130	I10301569	6e4db266	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:20.523808+01	2025-11-07 16:40:20.523808+01	\N
131	I10301567	77b5f901	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:22.813983+01	2025-11-07 16:40:22.813983+01	\N
132	I10301567	77b5f901	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:26.054114+01	2025-11-07 16:40:26.054114+01	\N
133	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I88118001Board Electrode 470/370/270	74df1208	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:40:38.551889+01	2025-11-07 16:40:38.551889+01	\N
134	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:42.025869+01	2025-11-07 16:40:42.025869+01	\N
135	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:45.603847+01	2025-11-07 16:40:45.603847+01	\N
136	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:49.272722+01	2025-11-07 16:40:49.272722+01	\N
137	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:51.842438+01	2025-11-07 16:40:51.842438+01	\N
138	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:55.518126+01	2025-11-07 16:40:55.518126+01	\N
139	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:40:59.035619+01	2025-11-07 16:40:59.035619+01	\N
140	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:02.842507+01	2025-11-07 16:41:02.842507+01	\N
141	I88118001	3d8c9c2d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:06.238189+01	2025-11-07 16:41:06.238189+01	\N
142	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F820001Board LNO6 470/270	6721deed	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:41:12.840901+01	2025-11-07 16:41:12.840901+01	\N
143	I8F920002	6d23d4b9	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:15.974879+01	2025-11-07 16:41:15.974879+01	\N
144	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F813001Board Analog 470/270	3dba3350	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:41:23.675784+01	2025-11-07 16:41:23.675784+01	\N
145	I8F813001	49fa9968	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:30.631263+01	2025-11-07 16:41:30.631263+01	\N
146	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101214Cable Foot 470/270 R	40a0a57b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:41:42.645809+01	2025-11-07 16:41:42.645809+01	\N
147	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:54.411805+01	2025-11-07 16:41:54.411805+01	\N
148	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:41:58.462411+01	2025-11-07 16:41:58.462411+01	\N
149	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:01.955212+01	2025-11-07 16:42:01.955212+01	\N
150	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:05.050354+01	2025-11-07 16:42:05.050354+01	\N
151	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:08.229943+01	2025-11-07 16:42:08.229943+01	\N
152	E01101214\r\n	bd3c84df	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:11.047957+01	2025-11-07 16:42:11.047957+01	\N
153	E01101214\r\n	bd3c84df	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:14.946674+01	2025-11-07 16:42:14.946674+01	\N
154	E01101214\r\n	bd3c84df	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:17.940955+01	2025-11-07 16:42:17.940955+01	\N
155	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:21.552788+01	2025-11-07 16:42:21.552788+01	\N
156	E01101214	c6ad8bc4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:42:25.043437+01	2025-11-07 16:42:25.043437+01	\N
157	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:10.592113+01	2025-11-07 16:43:10.592113+01	\N
158	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:15.38247+01	2025-11-07 16:43:15.38247+01	\N
159	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:19.040813+01	2025-11-07 16:43:19.040813+01	\N
160	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:22.722459+01	2025-11-07 16:43:22.722459+01	\N
161	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:26.421073+01	2025-11-07 16:43:26.421073+01	\N
162	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:28.282723+01	2025-11-07 16:43:28.282723+01	\N
163	E01101213\r\n	8c24b3a8	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:33.539697+01	2025-11-07 16:43:33.539697+01	\N
164	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:36.940768+01	2025-11-07 16:43:36.940768+01	\N
165	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:40.380295+01	2025-11-07 16:43:40.380295+01	\N
166	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:45.501157+01	2025-11-07 16:43:45.501157+01	\N
167	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:49.382422+01	2025-11-07 16:43:49.382422+01	\N
168	E01101213	27e92d57	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:43:53.321293+01	2025-11-07 16:43:53.321293+01	\N
169	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F921001Board Electrode Foot 470/270	189de30b	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:43:57.750614+01	2025-11-07 16:43:57.750614+01	\N
170	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:07.668171+01	2025-11-07 16:44:07.668171+01	\N
171	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:12.619324+01	2025-11-07 16:44:12.619324+01	\N
172	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:16.398257+01	2025-11-07 16:44:16.398257+01	\N
173	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:20.42853+01	2025-11-07 16:44:20.42853+01	\N
174	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:24.452172+01	2025-11-07 16:44:24.452172+01	\N
175	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:28.160521+01	2025-11-07 16:44:28.160521+01	\N
176	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:31.901196+01	2025-11-07 16:44:31.901196+01	\N
177	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:36.450814+01	2025-11-07 16:44:36.450814+01	\N
178	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:40.399838+01	2025-11-07 16:44:40.399838+01	\N
179	I8F921001	59f973a7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:44.914836+01	2025-11-07 16:44:44.914836+01	\N
180	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8F910001Board IF 470/270	1657f842	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:44:53.54283+01	2025-11-07 16:44:53.54283+01	\N
181	I8F910001	9a94305b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:44:59.050306+01	2025-11-07 16:44:59.050306+01	\N
182	I8F910001	9a94305b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:45:00.98184+01	2025-11-07 16:45:00.98184+01	\N
183	I8F910001	9a94305b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:45:05.452153+01	2025-11-07 16:45:05.452153+01	\N
184	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301220P_Hand Lower 570/470/270	4cd25850	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:45:41.357378+01	2025-11-07 16:45:41.357378+01	\N
185	I10301186	9dbc5df7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:45:49.46181+01	2025-11-07 16:45:49.46181+01	\N
186	I10301186	9dbc5df7	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:45:53.134268+01	2025-11-07 16:45:53.134268+01	\N
187	I10301220	e1d16569	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:02.89325+01	2025-11-07 16:46:02.89325+01	\N
188	I10301220	e1d16569	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:05.287697+01	2025-11-07 16:46:05.287697+01	\N
189	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301241P_Shoulder Back R 570/470/270	5957c2c2	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:46:14.392228+01	2025-11-07 16:46:14.392228+01	\N
190	I10301239\r\n	7162f2ab	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:16.745631+01	2025-11-07 16:46:16.745631+01	\N
191	I10301239\r\n	7162f2ab	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:24.533456+01	2025-11-07 16:46:24.533456+01	\N
192	I10301239\r\n	7162f2ab	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:41.239195+01	2025-11-07 16:46:41.239195+01	\N
193	I10301242	dd221623	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:46:48.933739+01	2025-11-07 16:46:48.933739+01	\N
194	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:50:24.056396+01	2025-11-07 16:50:24.056396+01	\N
195	I8P918001	0fa1f5b4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:50:28.479582+01	2025-11-07 16:50:28.479582+01	\N
196	I8P918001	0fa1f5b4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:50:32.227221+01	2025-11-07 16:50:32.227221+01	\N
197	I8P918001	0fa1f5b4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:50:35.305551+01	2025-11-07 16:50:35.305551+01	\N
198	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:50:49.357918+01	2025-11-07 16:50:49.357918+01	\N
199	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:50:58.697586+01	2025-11-07 16:50:58.697586+01	\N
200	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:02.247508+01	2025-11-07 16:51:02.247508+01	\N
201	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:07.246864+01	2025-11-07 16:51:07.246864+01	\N
202	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:10.502484+01	2025-11-07 16:51:10.502484+01	\N
203	I8F905001 	961b3c1f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:12.76128+01	2025-11-07 16:51:12.76128+01	\N
204	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301524Electrode Hand S 570/470/270	7154c629	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:51:26.089999+01	2025-11-07 16:51:26.089999+01	\N
205	I10301524	cae5b070	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:33.982295+01	2025-11-07 16:51:33.982295+01	\N
206	I10301524	cae5b070	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:42.536561+01	2025-11-07 16:51:42.536561+01	\N
207	I10301524	cae5b070	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:47.372613+01	2025-11-07 16:51:47.372613+01	\N
208	I10301524	cae5b070	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:51:55.914877+01	2025-11-07 16:51:55.914877+01	\N
209	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D313001Board Analog 570/J10New	8001a7f5	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:52:01.673537+01	2025-11-07 16:52:01.673537+01	\N
210	I8D313001	4556f7e3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:52:08.196327+01	2025-11-07 16:52:08.196327+01	\N
211	I8D313001	4556f7e3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:52:12.184728+01	2025-11-07 16:52:12.184728+01	\N
212	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D313001Board Analog 570/J10New	8001a7f5	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:58:06.795337+01	2025-11-07 16:58:06.795337+01	\N
213	I8D313001	4556f7e3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:58:23.089018+01	2025-11-07 16:58:23.089018+01	\N
214	I8D313001	4556f7e3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:58:29.244491+01	2025-11-07 16:58:29.244491+01	\N
215	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8G605001LCD Touch 570/370/S10	caf147e1	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 16:59:29.706088+01	2025-11-07 16:59:29.706088+01	\N
216	I8G605001	85d8d7b3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:59:32.889586+01	2025-11-07 16:59:32.889586+01	\N
217	I8G605001	85d8d7b3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:59:36.57478+01	2025-11-07 16:59:36.57478+01	\N
218	I8G605001	85d8d7b3	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:59:39.648256+01	2025-11-07 16:59:39.648256+01	\N
219	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 16:59:55.107044+01	2025-11-07 16:59:55.107044+01	\N
220	I8P999001	46df23de	ac8ee24e54707128	Code128	0	buffered	2025-11-07 16:59:58.214739+01	2025-11-07 16:59:58.214739+01	\N
221	I8P999001	46df23de	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:00.73363+01	2025-11-07 17:00:00.73363+01	\N
222	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:00:06.447092+01	2025-11-07 17:00:06.447092+01	\N
223	I10301844	ce126476	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:22.822493+01	2025-11-07 17:00:22.822493+01	\N
224	I10301844	ce126476	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:25.426869+01	2025-11-07 17:00:25.426869+01	\N
225	I10301844	ce126476	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:28.498034+01	2025-11-07 17:00:28.498034+01	\N
226	I10301844	ce126476	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:31.493141+01	2025-11-07 17:00:31.493141+01	\N
227	I10301843	2f56c2e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:34.325041+01	2025-11-07 17:00:34.325041+01	\N
228	I10301843	2f56c2e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:37.667682+01	2025-11-07 17:00:37.667682+01	\N
229	I10301843	2f56c2e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:40.692233+01	2025-11-07 17:00:40.692233+01	\N
230	I10301843	2f56c2e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:00:44.616327+01	2025-11-07 17:00:44.616327+01	\N
231	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301097P_Foot Case Cover 570/520	85ba8818	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:00:53.554046+01	2025-11-07 17:00:53.554046+01	\N
232	I10301097	702981ef	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:00.71378+01	2025-11-07 17:01:00.71378+01	\N
233	I10301097	702981ef	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:03.305265+01	2025-11-07 17:01:03.305265+01	\N
234	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8D325001Board Key 570 KNO4	9e0d436a	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:01:09.257571+01	2025-11-07 17:01:09.257571+01	\N
235	I10301625	96fa2676	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:17.296791+01	2025-11-07 17:01:17.296791+01	\N
236	I8D325001	f0822cb1	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:20.734779+01	2025-11-07 17:01:20.734779+01	\N
237	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I8G621001Board Electrode 570	22894725	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:01:29.117282+01	2025-11-07 17:01:29.117282+01	\N
238	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:36.616084+01	2025-11-07 17:01:36.616084+01	\N
239	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:41.907012+01	2025-11-07 17:01:41.907012+01	\N
240	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:45.811092+01	2025-11-07 17:01:45.811092+01	\N
241	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:49.312078+01	2025-11-07 17:01:49.312078+01	\N
242	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:53.559418+01	2025-11-07 17:01:53.559418+01	\N
243	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:01:57.901047+01	2025-11-07 17:01:57.901047+01	\N
244	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:01.494044+01	2025-11-07 17:02:01.494044+01	\N
245	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:05.603314+01	2025-11-07 17:02:05.603314+01	\N
246	I8G621001	5cbfba2f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:10.142481+01	2025-11-07 17:02:10.142481+01	\N
247	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:02:18.752006+01	2025-11-07 17:02:18.752006+01	\N
248	E01101152	690fbfea	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:29.340807+01	2025-11-07 17:02:29.340807+01	\N
249	E01101152	690fbfea	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:32.973789+01	2025-11-07 17:02:32.973789+01	\N
250	E01101152\r\n	04eb718c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:36.180076+01	2025-11-07 17:02:36.180076+01	\N
251	E01101152	690fbfea	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:40.594247+01	2025-11-07 17:02:40.594247+01	\N
252	E01101151	c6a6f220	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:44.898778+01	2025-11-07 17:02:44.898778+01	\N
253	E01101151	c6a6f220	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:47.967332+01	2025-11-07 17:02:47.967332+01	\N
254	E01101151	c6a6f220	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:50.726369+01	2025-11-07 17:02:50.726369+01	\N
255	E01101151	c6a6f220	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:02:54.064798+01	2025-11-07 17:02:54.064798+01	\N
256	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:03:03.483313+01	2025-11-07 17:03:03.483313+01	\N
257	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:13.513626+01	2025-11-07 17:03:13.513626+01	\N
258	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:17.573199+01	2025-11-07 17:03:17.573199+01	\N
259	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:20.794395+01	2025-11-07 17:03:20.794395+01	\N
260	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:23.76904+01	2025-11-07 17:03:23.76904+01	\N
261	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:26.598221+01	2025-11-07 17:03:26.598221+01	\N
262	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:29.429504+01	2025-11-07 17:03:29.429504+01	\N
263	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:32.439344+01	2025-11-07 17:03:32.439344+01	\N
264	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:35.876166+01	2025-11-07 17:03:35.876166+01	\N
265	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:41.251581+01	2025-11-07 17:03:41.251581+01	\N
266	I8G621002	f316f7e5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:03:45.908122+01	2025-11-07 17:03:45.908122+01	\N
267	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10301547Electrode Foot B 570/520	651b00ba	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:03:56.130321+01	2025-11-07 17:03:56.130321+01	\N
268	I10301547	9371f87c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:04:05.210872+01	2025-11-07 17:04:05.210872+01	\N
269	I10301548	efee885d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:04:16.468956+01	2025-11-07 17:04:16.468956+01	\N
270	I10301548	efee885d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:04:21.367847+01	2025-11-07 17:04:21.367847+01	\N
271	I10301548	efee885d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:04:25.926346+01	2025-11-07 17:04:25.926346+01	\N
272	I10301548	efee885d	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:04:28.966758+01	2025-11-07 17:04:28.966758+01	\N
273	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I10201098M_Hand Pipe 570	a2bee5a5	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:04:42.9818+01	2025-11-07 17:04:42.9818+01	\N
274	I10201098	a93d61c0	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:04.048848+01	2025-11-07 17:05:04.048848+01	\N
275	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:E01101153Cable Foot 570/520 L Blue	f4d23a21	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:05:22.339654+01	2025-11-07 17:05:22.339654+01	\N
276	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:30.510095+01	2025-11-07 17:05:30.510095+01	\N
277	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:33.866818+01	2025-11-07 17:05:33.866818+01	\N
278	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:37.039913+01	2025-11-07 17:05:37.039913+01	\N
279	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:40.630237+01	2025-11-07 17:05:40.630237+01	\N
280	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:43.63689+01	2025-11-07 17:05:43.63689+01	\N
281	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:46.822895+01	2025-11-07 17:05:46.822895+01	\N
282	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:50.883713+01	2025-11-07 17:05:50.883713+01	\N
283	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:54.0295+01	2025-11-07 17:05:54.0295+01	\N
284	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:05:57.762057+01	2025-11-07 17:05:57.762057+01	\N
285	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:09.127109+01	2025-11-07 17:06:09.127109+01	\N
286	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:11.948105+01	2025-11-07 17:06:11.948105+01	\N
287	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:14.62127+01	2025-11-07 17:06:14.62127+01	\N
288	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:17.507549+01	2025-11-07 17:06:17.507549+01	\N
289	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:20.620996+01	2025-11-07 17:06:20.620996+01	\N
290	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:23.613336+01	2025-11-07 17:06:23.613336+01	\N
291	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:27.024847+01	2025-11-07 17:06:27.024847+01	\N
292	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:31.170925+01	2025-11-07 17:06:31.170925+01	\N
293	E01101153	0c6884ac	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:53.002568+01	2025-11-07 17:06:53.002568+01	\N
294	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:56.395705+01	2025-11-07 17:06:56.395705+01	\N
295	E01101154	ed2c223f	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:06:58.916324+01	2025-11-07 17:06:58.916324+01	\N
296	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:07:25.90825+01	2025-11-07 17:07:25.90825+01	\N
297	I10301155	9ac49e6e	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:07:33.240754+01	2025-11-07 17:07:33.240754+01	\N
298	I10301155	9ac49e6e	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:07:36.430119+01	2025-11-07 17:07:36.430119+01	\N
299	I10301155	9ac49e6e	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:07:38.663151+01	2025-11-07 17:07:38.663151+01	\N
300	URL:mailto:support.de@inbody.com?subject=IBDEWH008[Parts Order]&body=Part%20number-Item%20description:I88120001[Not in use] Board LNO1 370/210/S10	52e4bb8c	ac8ee24e54707128	QRCODE	0	buffered	2025-11-07 17:07:49.786159+01	2025-11-07 17:07:49.786159+01	\N
301	I88120001	652b7623	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:08:11.924572+01	2025-11-07 17:08:11.924572+01	\N
302	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:08:37.352477+01	2025-11-07 17:08:37.352477+01	\N
303	I10301871	9e86368a	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:08:46.988594+01	2025-11-07 17:08:46.988594+01	\N
304	I10301871	9e86368a	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:08:54.407585+01	2025-11-07 17:08:54.407585+01	\N
305	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:08:59.121059+01	2025-11-07 17:08:59.121059+01	\N
306	I10301838	74c3dfc5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:12.331616+01	2025-11-07 17:09:12.331616+01	\N
307	I10301838	74c3dfc5	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:22.369195+01	2025-11-07 17:09:22.369195+01	\N
308	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:09:26.811033+01	2025-11-07 17:09:26.811033+01	\N
309	I10301859	e799e145	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:33.653025+01	2025-11-07 17:09:33.653025+01	\N
310	I10301859	e799e145	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:35.962593+01	2025-11-07 17:09:35.962593+01	\N
311	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:09:43.510838+01	2025-11-07 17:09:43.510838+01	\N
312	I10301805	b98c5b8b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:50.896657+01	2025-11-07 17:09:50.896657+01	\N
313	I10301805	b98c5b8b	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:09:59.709042+01	2025-11-07 17:09:59.709042+01	\N
314	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:10:13.303044+01	2025-11-07 17:10:13.303044+01	\N
315	I8R632001	cca48d04	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:13:03.608296+01	2025-11-07 17:13:03.608296+01	\N
316	I8R632001	cca48d04	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:13:06.119676+01	2025-11-07 17:13:06.119676+01	\N
317	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:14:53.410676+01	2025-11-07 17:14:53.410676+01	\N
318	I8P925001	cc2954fd	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:14:56.533442+01	2025-11-07 17:14:56.533442+01	\N
319	I8P925001	cc2954fd	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:00.188647+01	2025-11-07 17:15:00.188647+01	\N
320	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:15:09.551044+01	2025-11-07 17:15:09.551044+01	\N
321	I8P920001	57061fba	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:12.164169+01	2025-11-07 17:15:12.164169+01	\N
322	I8P920001	57061fba	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:14.992877+01	2025-11-07 17:15:14.992877+01	\N
323	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:15:25.737082+01	2025-11-07 17:15:25.737082+01	\N
324	I10301837	085cafe4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:50.421309+01	2025-11-07 17:15:50.421309+01	\N
325	I10301837	085cafe4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:55.489787+01	2025-11-07 17:15:55.489787+01	\N
326	I10301837	085cafe4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:15:58.989039+01	2025-11-07 17:15:58.989039+01	\N
327	I10301837	085cafe4	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:02.690591+01	2025-11-07 17:16:02.690591+01	\N
328	I10301836	6d3b94a2	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:08.697943+01	2025-11-07 17:16:08.697943+01	\N
329	I10301836	6d3b94a2	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:11.701445+01	2025-11-07 17:16:11.701445+01	\N
330	I10301836	6d3b94a2	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:14.522775+01	2025-11-07 17:16:14.522775+01	\N
331	I10301836	6d3b94a2	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:17.432707+01	2025-11-07 17:16:17.432707+01	\N
332	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:16:28.968618+01	2025-11-07 17:16:28.968618+01	\N
333	I10301806	16251641	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:16:32.780168+01	2025-11-07 17:16:32.780168+01	\N
334	5412386058608	614e2a61	ac8ee24e54707128	EAN-13	0	buffered	2025-11-07 17:16:39.882674+01	2025-11-07 17:16:39.882674+01	\N
335	I10301822	bc0cfc65	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:26.970826+01	2025-11-07 17:17:26.970826+01	\N
336	I10301822	bc0cfc65	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:32.914096+01	2025-11-07 17:17:32.914096+01	\N
337	I10301822	bc0cfc65	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:36.017963+01	2025-11-07 17:17:36.017963+01	\N
338	I10301822	bc0cfc65	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:38.922241+01	2025-11-07 17:17:38.922241+01	\N
339	I10301826	f2e1173c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:51.686235+01	2025-11-07 17:17:51.686235+01	\N
340	I10301826	f2e1173c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:54.76691+01	2025-11-07 17:17:54.76691+01	\N
341	I10301826	f2e1173c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:17:58.973002+01	2025-11-07 17:17:58.973002+01	\N
342	I10301826	f2e1173c	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:18:01.874387+01	2025-11-07 17:18:01.874387+01	\N
343	I10301825	5d485af6	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:18:11.745172+01	2025-11-07 17:18:11.745172+01	\N
344	I10301825	5d485af6	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:18:14.286818+01	2025-11-07 17:18:14.286818+01	\N
345	I10301825	5d485af6	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:18:17.000739+01	2025-11-07 17:18:17.000739+01	\N
346	I10301825	5d485af6	ac8ee24e54707128	Code128	0	buffered	2025-11-07 17:18:20.936737+01	2025-11-07 17:18:20.936737+01	\N
\.


--
-- Data for Name: schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_version (version, description, applied_at) FROM stdin;
1	Initial AI Support schema with pgvector and Apache AGE	2025-10-24 10:03:21.819589
3	OPAL Kurier integration - Added logistics tracking fields to repair_orders	2025-10-28 12:46:13.504134
\.


--
-- Data for Name: solution_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.solution_feedback (id, ticket_id, solution_id, was_helpful, feedback_text, rating, created_at) FROM stdin;
\.


--
-- Data for Name: solutions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.solutions (id, solution_title, problem_type, solution_text, solution_steps, applicable_models, tags, success_rate, usage_count, created_at, updated_at, created_by, embedding) FROM stdin;
1	Noise Interference Solution	noise_interference	Überprüfen Sie den Noise-Level und trennen Sie störende Geräte.	["Noise-Level prüfen (sollte <5mV sein)", "Drucker-Kabel trennen", "Anderen Raum testen", "Erdung überprüfen"]	{InBody270,InBody370,InBody770}	{noise,interference,measurement_error}	0	0	2025-10-24 10:12:29.697954	2025-10-24 10:12:29.697954	\N	\N
2	Measurement Error - Calibration	measurement_error	Gerät neu kalibrieren und Elektroden reinigen.	["Gerät ausschalten", "Elektroden mit Alkohol reinigen", "10 Minuten warten", "Kalibrierung durchführen"]	{InBody270,InBody370,InBody570,InBody770}	{calibration,electrodes,measurement}	0	0	2025-10-24 10:12:29.697954	2025-10-24 10:12:29.697954	\N	\N
\.


--
-- Data for Name: support_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_cases (id, ticket_number, customer_email, customer_name, device_model, device_serial, problem_category, problem_description, solution_applied, resolution_status, priority, assigned_to, created_at, resolved_at, updated_at, embedding) FROM stdin;
\.


--
-- Data for Name: translation_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.translation_cache (key, language, "originalText", "translatedText", context, "lastUsed", "useCount", "charCount", "processingTime", source, "apiVersion", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_auth (id, username, email, password, "googleId", name, company, phone, street, "houseNumber", "postalCode", city, country, "lastLogin", role, "userType", "rmaReference", "isActive", "createdAt", "updatedAt") FROM stdin;
3085a49b-1b1a-4a9b-abcf-18ae8aaa26a4	admin	admin@eckwms.local	$2b$10$ok2zY.MrnQkcCZJA/A2KaOcu5iIiiE9ckbia.Axm.0.Ice62dwDPO	\N	Administrator	eckWMS	\N	\N	\N	\N	\N	\N	2025-11-14 13:23:18.753+01	admin	company	\N	t	2025-11-10 15:50:02.042+01	2025-11-14 13:23:18.754+01
\.


--
-- Name: ai_response_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_response_cache_id_seq', 1, false);


--
-- Name: ai_support_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_support_metrics_id_seq', 1, false);


--
-- Name: conversation_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.conversation_history_id_seq', 1, false);


--
-- Name: device_knowledge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_knowledge_id_seq', 1, false);


--
-- Name: email_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.email_archive_id_seq', 1, false);


--
-- Name: repair_defective_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_defective_parts_id_seq', 1, true);


--
-- Name: repair_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_documents_id_seq', 1, false);


--
-- Name: repair_error_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_error_categories_id_seq', 8, true);


--
-- Name: repair_firmware_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_firmware_history_id_seq', 1, false);


--
-- Name: repair_laptop_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_laptop_config_id_seq', 1, false);


--
-- Name: repair_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_orders_id_seq', 164, true);


--
-- Name: repair_package_contents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_package_contents_id_seq', 1, false);


--
-- Name: repair_solution_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_solution_categories_id_seq', 6, true);


--
-- Name: repair_support_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repair_support_links_id_seq', 1, false);


--
-- Name: solution_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.solution_feedback_id_seq', 1, false);


--
-- Name: solutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.solutions_id_seq', 2, true);


--
-- Name: support_cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.support_cases_id_seq', 1, false);


--
-- Name: ai_response_cache ai_response_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_response_cache
    ADD CONSTRAINT ai_response_cache_pkey PRIMARY KEY (id);


--
-- Name: ai_support_metrics ai_support_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_support_metrics
    ADD CONSTRAINT ai_support_metrics_pkey PRIMARY KEY (id);


--
-- Name: conversation_history conversation_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_history
    ADD CONSTRAINT conversation_history_pkey PRIMARY KEY (id);


--
-- Name: device_knowledge device_knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_knowledge
    ADD CONSTRAINT device_knowledge_pkey PRIMARY KEY (id);


--
-- Name: eckwms_instances eckwms_instances_api_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eckwms_instances
    ADD CONSTRAINT eckwms_instances_api_key_key UNIQUE (api_key);


--
-- Name: eckwms_instances eckwms_instances_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eckwms_instances
    ADD CONSTRAINT eckwms_instances_name_key UNIQUE (name);


--
-- Name: eckwms_instances eckwms_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eckwms_instances
    ADD CONSTRAINT eckwms_instances_pkey PRIMARY KEY (id);


--
-- Name: email_archive email_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_archive
    ADD CONSTRAINT email_archive_pkey PRIMARY KEY (id);


--
-- Name: public_data public_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.public_data
    ADD CONSTRAINT public_data_pkey PRIMARY KEY (id);


--
-- Name: registered_devices registered_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registered_devices
    ADD CONSTRAINT registered_devices_pkey PRIMARY KEY ("deviceId");


--
-- Name: repair_defective_parts repair_defective_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_defective_parts
    ADD CONSTRAINT repair_defective_parts_pkey PRIMARY KEY (id);


--
-- Name: repair_documents repair_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_documents
    ADD CONSTRAINT repair_documents_pkey PRIMARY KEY (id);


--
-- Name: repair_error_categories repair_error_categories_category_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_error_categories
    ADD CONSTRAINT repair_error_categories_category_key_key UNIQUE (category_key);


--
-- Name: repair_error_categories repair_error_categories_category_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_error_categories
    ADD CONSTRAINT repair_error_categories_category_name_key UNIQUE (category_name);


--
-- Name: repair_error_categories repair_error_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_error_categories
    ADD CONSTRAINT repair_error_categories_pkey PRIMARY KEY (id);


--
-- Name: repair_firmware_history repair_firmware_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_firmware_history
    ADD CONSTRAINT repair_firmware_history_pkey PRIMARY KEY (id);


--
-- Name: repair_laptop_config repair_laptop_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_laptop_config
    ADD CONSTRAINT repair_laptop_config_pkey PRIMARY KEY (id);


--
-- Name: repair_orders repair_orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_orders
    ADD CONSTRAINT repair_orders_order_number_key UNIQUE (order_number);


--
-- Name: repair_orders repair_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_orders
    ADD CONSTRAINT repair_orders_pkey PRIMARY KEY (id);


--
-- Name: repair_package_contents repair_package_contents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_package_contents
    ADD CONSTRAINT repair_package_contents_pkey PRIMARY KEY (id);


--
-- Name: repair_solution_categories repair_solution_categories_category_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_solution_categories
    ADD CONSTRAINT repair_solution_categories_category_key_key UNIQUE (category_key);


--
-- Name: repair_solution_categories repair_solution_categories_category_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_solution_categories
    ADD CONSTRAINT repair_solution_categories_category_name_key UNIQUE (category_name);


--
-- Name: repair_solution_categories repair_solution_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_solution_categories
    ADD CONSTRAINT repair_solution_categories_pkey PRIMARY KEY (id);


--
-- Name: repair_support_links repair_support_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_support_links
    ADD CONSTRAINT repair_support_links_pkey PRIMARY KEY (id);


--
-- Name: rma_requests rma_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rma_requests
    ADD CONSTRAINT rma_requests_pkey PRIMARY KEY (id);


--
-- Name: rma_requests rma_requests_rmaCode_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rma_requests
    ADD CONSTRAINT "rma_requests_rmaCode_key" UNIQUE ("rmaCode");


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: schema_version schema_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_version
    ADD CONSTRAINT schema_version_pkey PRIMARY KEY (version);


--
-- Name: solution_feedback solution_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solution_feedback
    ADD CONSTRAINT solution_feedback_pkey PRIMARY KEY (id);


--
-- Name: solutions solutions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_pkey PRIMARY KEY (id);


--
-- Name: support_cases support_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT support_cases_pkey PRIMARY KEY (id);


--
-- Name: support_cases support_cases_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT support_cases_ticket_number_key UNIQUE (ticket_number);


--
-- Name: translation_cache translation_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.translation_cache
    ADD CONSTRAINT translation_cache_pkey PRIMARY KEY (key, language);


--
-- Name: ai_support_metrics unique_metric_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_support_metrics
    ADD CONSTRAINT unique_metric_date UNIQUE (metric_date);


--
-- Name: repair_firmware_history unique_repair_firmware; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_firmware_history
    ADD CONSTRAINT unique_repair_firmware UNIQUE (repair_order_id);


--
-- Name: repair_laptop_config unique_repair_laptop; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_laptop_config
    ADD CONSTRAINT unique_repair_laptop UNIQUE (repair_order_id);


--
-- Name: repair_package_contents unique_repair_package; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_package_contents
    ADD CONSTRAINT unique_repair_package UNIQUE (repair_order_id);


--
-- Name: repair_defective_parts unique_repair_part_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_defective_parts
    ADD CONSTRAINT unique_repair_part_position UNIQUE (repair_order_id, "position");


--
-- Name: repair_support_links unique_repair_support_link; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_support_links
    ADD CONSTRAINT unique_repair_support_link UNIQUE (repair_order_id, support_case_id);


--
-- Name: user_auth user_auth_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT user_auth_email_key UNIQUE (email);


--
-- Name: user_auth user_auth_googleId_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT "user_auth_googleId_key" UNIQUE ("googleId");


--
-- Name: user_auth user_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT user_auth_pkey PRIMARY KEY (id);


--
-- Name: user_auth user_auth_rmaReference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT "user_auth_rmaReference_key" UNIQUE ("rmaReference");


--
-- Name: user_auth user_auth_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth
    ADD CONSTRAINT user_auth_username_key UNIQUE (username);


--
-- Name: ai_cache_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ai_cache_embedding_idx ON public.ai_response_cache USING ivfflat (query_embedding public.vector_cosine_ops) WITH (lists='50');


--
-- Name: email_archive_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_archive_embedding_idx ON public.email_archive USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_conversation_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_conversation_ticket ON public.conversation_history USING btree (ticket_id, created_at);


--
-- Name: idx_defective_parts_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defective_parts_category ON public.repair_defective_parts USING btree (part_category);


--
-- Name: idx_defective_parts_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defective_parts_name ON public.repair_defective_parts USING btree (part_name);


--
-- Name: idx_defective_parts_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_defective_parts_order ON public.repair_defective_parts USING btree (repair_order_id);


--
-- Name: idx_device_knowledge_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_knowledge_category ON public.device_knowledge USING btree (issue_category);


--
-- Name: idx_device_knowledge_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_knowledge_model ON public.device_knowledge USING btree (device_model);


--
-- Name: idx_email_archive_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_archive_date ON public.email_archive USING btree (email_date DESC);


--
-- Name: idx_email_archive_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_archive_from ON public.email_archive USING btree (from_address);


--
-- Name: idx_email_archive_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_archive_ticket ON public.email_archive USING btree (ticket_id);


--
-- Name: idx_feedback_helpful; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_helpful ON public.solution_feedback USING btree (was_helpful);


--
-- Name: idx_feedback_solution; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feedback_solution ON public.solution_feedback USING btree (solution_id);


--
-- Name: idx_firmware_changed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_firmware_changed ON public.repair_firmware_history USING btree (kernel_changed, digital_changed, analog_changed);


--
-- Name: idx_firmware_history_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_firmware_history_order ON public.repair_firmware_history USING btree (repair_order_id);


--
-- Name: idx_firmware_kernel_before; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_firmware_kernel_before ON public.repair_firmware_history USING btree (kernel_before);


--
-- Name: idx_laptop_config_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_laptop_config_order ON public.repair_laptop_config USING btree (repair_order_id);


--
-- Name: idx_laptop_os; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_laptop_os ON public.repair_laptop_config USING btree (operating_system);


--
-- Name: idx_laptop_software; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_laptop_software ON public.repair_laptop_config USING btree (software_name, software_version);


--
-- Name: idx_metrics_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_metrics_date ON public.ai_support_metrics USING btree (metric_date DESC);


--
-- Name: idx_package_contents_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_package_contents_order ON public.repair_package_contents USING btree (repair_order_id);


--
-- Name: idx_repair_documents_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_documents_created ON public.repair_documents USING btree (created_at DESC);


--
-- Name: idx_repair_documents_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_documents_order ON public.repair_documents USING btree (repair_order_id);


--
-- Name: idx_repair_documents_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_documents_type ON public.repair_documents USING btree (document_type);


--
-- Name: idx_repair_orders_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_created ON public.repair_orders USING btree (created_at DESC);


--
-- Name: idx_repair_orders_cs_de; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_cs_de ON public.repair_orders USING btree (cs_de_order_number);


--
-- Name: idx_repair_orders_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_customer ON public.repair_orders USING btree (customer_name);


--
-- Name: idx_repair_orders_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_device ON public.repair_orders USING btree (device_model, device_serial);


--
-- Name: idx_repair_orders_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_email ON public.repair_orders USING btree (customer_email);


--
-- Name: idx_repair_orders_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_number ON public.repair_orders USING btree (order_number);


--
-- Name: idx_repair_orders_opal_actual_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_actual_status ON public.repair_orders USING btree (opal_actual_delivery_status);


--
-- Name: idx_repair_orders_opal_hwb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_hwb ON public.repair_orders USING btree (opal_hwb_number);


--
-- Name: idx_repair_orders_opal_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_order_id ON public.repair_orders USING btree (opal_order_id);


--
-- Name: idx_repair_orders_opal_shipping_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_shipping_date ON public.repair_orders USING btree (opal_shipping_date DESC);


--
-- Name: idx_repair_orders_opal_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_status ON public.repair_orders USING btree (opal_status);


--
-- Name: idx_repair_orders_opal_tracking; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_tracking ON public.repair_orders USING btree (opal_tracking_number);


--
-- Name: idx_repair_orders_opal_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_opal_updated ON public.repair_orders USING btree (opal_last_updated DESC);


--
-- Name: idx_repair_orders_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_scan_id ON public.repair_orders USING btree (scan_id);


--
-- Name: idx_repair_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_status ON public.repair_orders USING btree (repair_status);


--
-- Name: idx_repair_orders_warranty; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_warranty ON public.repair_orders USING btree (warranty);


--
-- Name: idx_repair_orders_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_orders_year ON public.repair_orders USING btree (year);


--
-- Name: idx_repair_support_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_support_case ON public.repair_support_links USING btree (support_case_id);


--
-- Name: idx_repair_support_repair; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repair_support_repair ON public.repair_support_links USING btree (repair_order_id);


--
-- Name: idx_scans_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_created_at ON public.scans USING btree ("createdAt" DESC);


--
-- Name: idx_scans_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_device_id ON public.scans USING btree ("deviceId");


--
-- Name: idx_scans_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_instance_id ON public.scans USING btree (instance_id);


--
-- Name: idx_scans_instance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_instance_status ON public.scans USING btree (instance_id, status);


--
-- Name: idx_scans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scans_status ON public.scans USING btree (status);


--
-- Name: idx_solutions_models; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solutions_models ON public.solutions USING gin (applicable_models);


--
-- Name: idx_solutions_problem_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solutions_problem_type ON public.solutions USING btree (problem_type);


--
-- Name: idx_solutions_success_rate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solutions_success_rate ON public.solutions USING btree (success_rate DESC);


--
-- Name: idx_solutions_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_solutions_tags ON public.solutions USING gin (tags);


--
-- Name: idx_support_cases_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_cases_created ON public.support_cases USING btree (created_at DESC);


--
-- Name: idx_support_cases_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_cases_device ON public.support_cases USING btree (device_model, device_serial);


--
-- Name: idx_support_cases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_cases_status ON public.support_cases USING btree (resolution_status);


--
-- Name: idx_support_cases_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_cases_ticket ON public.support_cases USING btree (ticket_number);


--
-- Name: repair_documents_content_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_documents_content_embedding_idx ON public.repair_documents USING ivfflat (content_embedding public.vector_cosine_ops) WITH (lists='50');


--
-- Name: repair_orders_customer_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_customer_name ON public.repair_orders USING btree (customer_name);


--
-- Name: repair_orders_device_model_device_serial; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_device_model_device_serial ON public.repair_orders USING btree (device_model, device_serial);


--
-- Name: repair_orders_error_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_error_embedding_idx ON public.repair_orders USING ivfflat (error_embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: repair_orders_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_order_number ON public.repair_orders USING btree (order_number);


--
-- Name: repair_orders_repair_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_repair_status ON public.repair_orders USING btree (repair_status);


--
-- Name: repair_orders_scan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_scan_id ON public.repair_orders USING btree (scan_id);


--
-- Name: repair_orders_solution_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_solution_embedding_idx ON public.repair_orders USING ivfflat (solution_embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: repair_orders_warranty; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_warranty ON public.repair_orders USING btree (warranty);


--
-- Name: repair_orders_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX repair_orders_year ON public.repair_orders USING btree (year);


--
-- Name: scans_instance_id_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scans_instance_id_created_at ON public.scans USING btree (instance_id, "createdAt");


--
-- Name: scans_instance_id_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX scans_instance_id_status ON public.scans USING btree (instance_id, status);


--
-- Name: solutions_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX solutions_embedding_idx ON public.solutions USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: support_cases_embedding_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_cases_embedding_idx ON public.support_cases USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: translation_cache_language_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX translation_cache_language_key ON public.translation_cache USING btree (language, key);


--
-- Name: translation_cache_language_last_used; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX translation_cache_language_last_used ON public.translation_cache USING btree (language, "lastUsed");


--
-- Name: translation_cache_source_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX translation_cache_source_created_at ON public.translation_cache USING btree (source, "createdAt");


--
-- Name: translation_cache_use_count; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX translation_cache_use_count ON public.translation_cache USING btree ("useCount");


--
-- Name: v_device_repair_history _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_device_repair_history AS
 SELECT ro.device_serial,
    ro.device_model,
    ro.order_number,
    ro.date_of_receipt,
    ro.error_description,
    ro.troubleshooting,
    ro.warranty,
    json_agg(json_build_object('part_name', rdp.part_name, 'part_category', rdp.part_category)) FILTER (WHERE (rdp.id IS NOT NULL)) AS defective_parts,
    ro.created_at
   FROM (public.repair_orders ro
     LEFT JOIN public.repair_defective_parts rdp ON ((rdp.repair_order_id = ro.id)))
  WHERE (ro.device_serial IS NOT NULL)
  GROUP BY ro.id
  ORDER BY ro.device_serial, ro.created_at DESC;


--
-- Name: v_open_tickets _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_open_tickets AS
 SELECT sc.id,
    sc.ticket_number,
    sc.customer_email,
    sc.device_model,
    sc.device_serial,
    sc.problem_description,
    sc.priority,
    sc.created_at,
    count(ch.id) AS message_count
   FROM (public.support_cases sc
     LEFT JOIN public.conversation_history ch ON ((ch.ticket_id = sc.id)))
  WHERE ((sc.resolution_status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying])::text[]))
  GROUP BY sc.id;


--
-- Name: v_solution_effectiveness _RETURN; Type: RULE; Schema: public; Owner: -
--

CREATE OR REPLACE VIEW public.v_solution_effectiveness AS
 SELECT s.id AS solution_id,
    s.solution_title,
    s.problem_type,
    s.usage_count,
    s.success_rate,
    count(sf.id) AS feedback_count,
    (avg(sf.rating))::numeric(3,2) AS avg_rating,
    ((sum(
        CASE
            WHEN sf.was_helpful THEN 1
            ELSE 0
        END))::double precision / (NULLIF(count(sf.id), 0))::double precision) AS helpful_ratio
   FROM (public.solutions s
     LEFT JOIN public.solution_feedback sf ON ((sf.solution_id = s.id)))
  GROUP BY s.id;


--
-- Name: scans trigger_update_scans_timestamp; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_update_scans_timestamp BEFORE UPDATE ON public.scans FOR EACH ROW EXECUTE FUNCTION public.update_scans_updated_at();


--
-- Name: device_knowledge update_device_knowledge_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_device_knowledge_updated_at BEFORE UPDATE ON public.device_knowledge FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: solutions update_solutions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_solutions_updated_at BEFORE UPDATE ON public.solutions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: support_cases update_support_cases_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_support_cases_updated_at BEFORE UPDATE ON public.support_cases FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: conversation_history conversation_history_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_history
    ADD CONSTRAINT conversation_history_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- Name: device_knowledge device_knowledge_solution_reference_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_knowledge
    ADD CONSTRAINT device_knowledge_solution_reference_fkey FOREIGN KEY (solution_reference) REFERENCES public.solutions(id);


--
-- Name: email_archive email_archive_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_archive
    ADD CONSTRAINT email_archive_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_cases(id) ON DELETE SET NULL;


--
-- Name: registered_devices registered_devices_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registered_devices
    ADD CONSTRAINT registered_devices_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.eckwms_instances(id) ON DELETE SET NULL;


--
-- Name: repair_defective_parts repair_defective_parts_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_defective_parts
    ADD CONSTRAINT repair_defective_parts_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_documents repair_documents_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_documents
    ADD CONSTRAINT repair_documents_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_firmware_history repair_firmware_history_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_firmware_history
    ADD CONSTRAINT repair_firmware_history_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_laptop_config repair_laptop_config_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_laptop_config
    ADD CONSTRAINT repair_laptop_config_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_orders repair_orders_scan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_orders
    ADD CONSTRAINT repair_orders_scan_id_fkey FOREIGN KEY (scan_id) REFERENCES public.scans(id) ON DELETE SET NULL;


--
-- Name: repair_package_contents repair_package_contents_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_package_contents
    ADD CONSTRAINT repair_package_contents_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_support_links repair_support_links_repair_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_support_links
    ADD CONSTRAINT repair_support_links_repair_order_id_fkey FOREIGN KEY (repair_order_id) REFERENCES public.repair_orders(id) ON DELETE CASCADE;


--
-- Name: repair_support_links repair_support_links_support_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_support_links
    ADD CONSTRAINT repair_support_links_support_case_id_fkey FOREIGN KEY (support_case_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- Name: rma_requests rma_requests_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rma_requests
    ADD CONSTRAINT "rma_requests_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.user_auth(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scans scans_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.eckwms_instances(id) ON DELETE SET NULL;


--
-- Name: solution_feedback solution_feedback_solution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solution_feedback
    ADD CONSTRAINT solution_feedback_solution_id_fkey FOREIGN KEY (solution_id) REFERENCES public.solutions(id) ON DELETE CASCADE;


--
-- Name: solution_feedback solution_feedback_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solution_feedback
    ADD CONSTRAINT solution_feedback_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 7RBUyRXz98O6vySvCxqV1Xf5xDP9xHMIQ27H2RPVeBrzl4Dc3rkgc0LWd44X3dR

